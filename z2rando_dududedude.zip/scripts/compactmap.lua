-- The image to set to on right click, for this pack it's mountains
local OnRightClickMapImage = "images/terrain/mountain.png"

-- The amount of separate compact map squares to create, will be created as compactmap(one through set count)
local CompactMapLocationCount = 256

-- Define items to add to the palette by adding the necesarry data here
-- Attributes set are similar to what you'd do when defining items in json, just slightly less verbose
local PaletteData = {
	-- Define default square here, this is what any compact map square will default to, or revert to when the applied palette is removed
	[0] = {
		["name"] = "Blank",
		["code"] = "paletteblank",
		["image"] = "images/terrain/blank.png"
	},

	-- Palaces
	
	{
		["name"] = "Palace",
		["code"] = "palettepalace",
		["image"] = "images/terrain/palace.png"
	},
	
	{
		["name"] = "Palace 1",
		["code"] = "palettepalace1",
		["image"] = "images/terrain/palace1.png"
	},
	
	{
		["name"] = "Palace 2",
		["code"] = "palettepalace2",
		["image"] = "images/terrain/palace2.png"
	},
	
	{
		["name"] = "Palace 3",
		["code"] = "palettepalace3",
		["image"] = "images/terrain/palace3.png"
	},
	
	{
		["name"] = "Palace 4",
		["code"] = "palettepalace4",
		["image"] = "images/terrain/palace4.png"
	},
	
	{
		["name"] = "Palace 5",
		["code"] = "palettepalace5",
		["image"] = "images/terrain/palace5.png"
	},
	
	{
		["name"] = "Palace 6",
		["code"] = "palettepalace6",
		["image"] = "images/terrain/palace6.png"
	},
	
	{
		["name"] = "Great Palace",
		["code"] = "palettepalace7",
		["image"] = "images/terrain/palace7.png"
	},

	-- Towns
	
	{
		["name"] = "Town",
		["code"] = "palettetown",
		["image"] = "images/terrain/town.png"
	},
	
	{
		["name"] = "Rauru",
		["code"] = "palettetown1",
		["image"] = "images/terrain/town1.png"
	},
	
	{
		["name"] = "Ruto",
		["code"] = "palettetown2",
		["image"] = "images/terrain/town2.png"
	},
	
	{
		["name"] = "Saria",
		["code"] = "palettetown3",
		["image"] = "images/terrain/town3.png"
	},
	
	{
		["name"] = "Mido",
		["code"] = "palettetown4",
		["image"] = "images/terrain/town4.png"
	},
	
	{
		["name"] = "Nabooru",
		["code"] = "palettetown5",
		["image"] = "images/terrain/town5.png"
	},
	
	{
		["name"] = "Darunia",
		["code"] = "palettetown6",
		["image"] = "images/terrain/town6.png"
	},
	
	{
		["name"] = "New Kasuto",
		["code"] = "palettetown7",
		["image"] = "images/terrain/town7.png"
	},
	
	{
		["name"] = "Kasuto",
		["code"] = "palettetown8",
		["image"] = "images/terrain/town8.png"
	},
	
	-- Connections
	
	{
		["name"] = "Death Mountain Entrance",
		["code"] = "palettedm",
		["image"] = "images/terrain/dmentrance.png"
	},
	
	{
		["name"] = "Connector Cave",
		["code"] = "paletteconnectora",
		["image"] = "images/terrain/connectora.png"
	},
	
	{
		["name"] = "Connector Cave",
		["code"] = "paletteconnectorb",
		["image"] = "images/terrain/connectorb.png"
	},
	
	{
		["name"] = "Connector Cave",
		["code"] = "paletteconnectorc",
		["image"] = "images/terrain/connectorc.png"
	},
	
	{
		["name"] = "Connector Cave",
		["code"] = "paletteconnectord",
		["image"] = "images/terrain/connectord.png"
	},
	
	{
		["name"] = "Bridge / Dock",
		["code"] = "palettebridge",
		["image"] = "images/terrain/bridge.png"
	},
	
	-- Item Blocks
	
	{
		["name"] = "Boulder",
		["code"] = "paletteboulder",
		["image"] = "images/terrain/boulder.png"
	},
	
	{
		["name"] = "River Devil",
		["code"] = "paletteriverdevil",
		["image"] = "images/terrain/riverdevil.png"
	},
	
	-- Terrain
	
	{
		["name"] = "Desert",
		["code"] = "palettedesert",
		["image"] = "images/terrain/desert.png"
	},
	
	{
		["name"] = "Forest",
		["code"] = "paletteforest",
		["image"] = "images/terrain/forest.png"
	},
	
	{
		["name"] = "Grass",
		["code"] = "palettegrass",
		["image"] = "images/terrain/grass.png"
	},
	
	{
		["name"] = "Graveyard",
		["code"] = "palettegrave",
		["image"] = "images/terrain/grave.png"
	},
	
	{
		["name"] = "Swamp",
		["code"] = "paletteswamp",
		["image"] = "images/terrain/swamp.png"
	},
	
	{
		["name"] = "Water",
		["code"] = "palettewater",
		["image"] = "images/terrain/water.png"
	}
}

local BlankImage
local CurrentPalette

PaletteItem = class(CustomItem)

-- PaletteItems are the mutually exclusive items that you use to control what you're putting on a map square
-- There are no properties used on this one since we do not want this item to change by using undo
-- In addition there is no handling for saving and loading since we want it to return to its default state if a save is loaded

function PaletteItem:init(name,code,image,index)
	self:createItem(name)
	self.code = code
	self.Active = false
	self.activeImage = image
	self.index = index
	self.disabledImage = ImageReference:FromImageReference(self.activeImage, "@disabled")
	self.ItemInstance.PotentialIcon = self.activeImage
	
	-- The 0 indexed item is our default state, and also the state our palette should start as
	if (index == 0) then
		BlankImage = self
		CurrentPalette = self
	end
	
	self:UpdateIcon()
end

function PaletteItem:UpdateIcon()
	if self.Active then
		self.ItemInstance.Icon = self.activeImage
	else
		self.ItemInstance.Icon = self.disabledImage
	end
end

function PaletteItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function PaletteItem:providesCode(code)
    if code == self.code and self.Active then
        return 1
    end
    return 0
end

function PaletteItem:onLeftClick()
	-- Technically this works fine without checking if the item isn't active, but this is cleaner
	if not self.Active then
		CurrentPalette.Active = false
		CurrentPalette:UpdateIcon()
		CurrentPalette = self
		self.Active = true
		-- Since we're not using setProperty we also can't use PropertyChanged() and so have to push the icon update here.
		self:UpdateIcon()
	end
end

function PaletteItem:onRightClick()
	-- We do need to double check that the user is right-clicking an active palette item before we set the palette to BlankImage
	if self.Active then
		CurrentPalette = BlankImage
		self.Active = false
		-- Since we're not using setProperty we also can't use PropertyChanged() and so have to push the icon update here
		self:UpdateIcon()
	end
end

-- Since we're not interested in saving palette state, we make the save function return nothing instead of the default empty table
function PaletteItem:save()
end

for i,data in pairs(PaletteData) do
	-- We convert the image paths to references here to make them easier to reference later
	data["image"] = ImageReference:FromPackRelativePath(data["image"])
	local newItem = PaletteItem(data["name"], data["code"], data["image"], i)
end

-- CompactMapItem is the squares that make up the map
-- Properties:
-- active - boolean if item is active or not
-- index - integer storing the index of the current palette, corresponding to its position in PaletteData
-- Variables:
-- self.RightClickImage - The image to be set to when the square is right-clicked
-- self.AssignedImage - The image that the square has currently been set to by left-clicking

CompactMapItem = class(CustomItem)

-- Codes are incremented through passing the i value of a for loop
-- We don't need any other variables passed on init since the rest is fixed information
function CompactMapItem:init(iteration,continent)
	self:createItem("Compact Map")
    self.code = "compactmap" .. continent .. iteration
	self:setProperty("active", false)
	self:setProperty("index", BlankImage.index)
    self.RightClickImage = ImageReference:FromPackRelativePath(OnRightClickMapImage)
    self.AssignedImage = self:getPalette()
    self.ItemInstance.PotentialIcon = self.RightClickImage

    self:updateIcon()
end

function CompactMapItem:getPalette()
	return PaletteData[self:getIndex()]["image"]
end

function CompactMapItem:getActive()
	return self:getProperty("active")
end

function CompactMapItem:getIndex()
	return self:getProperty("index")
end

function CompactMapItem:updateIcon()
	if self:getActive() then
		self.ItemInstance.Icon = self.RightClickImage
	else
		self.ItemInstance.Icon = self.AssignedImage
	end
end

function CompactMapItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function CompactMapItem:providesCode(code)
    if code == self.code and self:getActive() then
        return 1
    end
    return 0
end

function CompactMapItem:onLeftClick()
	-- If the index on our clicked square is the same as the index of our palette, set to the blank index
	if self:getIndex() == CurrentPalette.index then
		self:setProperty("index", BlankImage.index)
	-- Otherwise, set it to the index of our active palette
	else
		self:setProperty("index", CurrentPalette.index)
	end
end

-- Right clicking swaps between the item set as OnRightClickMapImage showing or not
-- Worth mentioning that right-clicking purposefully doesn't delete the underlying item
-- It's friendlier for misclicks that way
function CompactMapItem:onRightClick()
	if self:getActive() then
		self:setProperty("active", false)
	else
		self:setProperty("active", true)
	end
end

function CompactMapItem:propertyChanged(key, value)
	-- If the property changed was the index, we need to update AssignedImage used
	if key == "index" then
		self.AssignedImage = self:getPalette()
	end
    self:updateIcon()
end

-- Unlike the PaletteItems we do save the properties we've set here, we want them to show up again if someone saves/loads
function CompactMapItem:save()
    local saveData = {
		["active"] = self:getActive(),
		["index"] = self:getIndex()
	}
    return saveData
end

function CompactMapItem:load(data)
    if data ~= nil then
        self:setProperty("active", data["active"])
		self:setProperty("index", data["index"])
	end
    return true
end

for i=1,CompactMapLocationCount do
	local newItem = CompactMapItem(i, "west")
	local newItem = CompactMapItem(i, "east")
end