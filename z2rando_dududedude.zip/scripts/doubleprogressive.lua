-- Attributes set are similar to what you'd do when defining items in json, just slightly less verbose
local ItemData = {
	{
		["name"] = "Trophy",
		["code"] = {"trophy", "figurine", "statue"},
		["image"] = "images/items/trophy.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
			"overlay|images/overlays/x.png"
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},

	{
		["name"] = "Water of Life",
		["code"] = {"wateroflife", "medicine"},
		["image"] = "images/items/wateroflife.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
			"overlay|images/overlays/x.png"
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},	
	
	{
		["name"] = "Kid",
		["code"] = {"kid", "child"},
		["image"] = "images/items/kid.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
			"overlay|images/overlays/x.png"
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Boots",
		["code"] = {"boots", "boot"},
		["image"] = "images/items/boots.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Candle",
		["code"] = {"candle"},
		["image"] = "images/items/candle.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Cross",
		["code"] = {"cross"},
		["image"] = "images/items/cross.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Flute",
		["code"] = {"flute", "recorder"},
		["image"] = "images/items/flute.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Glove",
		["code"] = {"glove", "gauntlet"},
		["image"] = "images/items/glove.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Hammer",
		["code"] = {"hammer"},
		["image"] = "images/items/hammer.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Magic Key",
		["code"] = {"magickey", "anyjey"},
		["image"] = "images/items/magickey.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Raft",
		["code"] = {"raft"},
		["image"] = "images/items/raft.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	}
}
-- In this particular case the overlays are the same for all items 
-- I've coded it this way any way for easier customizability in case of use elsewhere later

DoubleProgressiveItem = CustomItem:extend()

-- A double progressive item is a progressive item that has multiple stages for both its left and right click interactions

function DoubleProgressiveItem:init(name,code,image,lco,rco)
	self:createItem(name)
	self.name = name
	self.code = code
	self.image = ImageReference:FromPackRelativePath(image)
	self.lco = lco
	self.lcomax = 0
	for i,data in pairs(self.lco) do
		self.lcomax = self.lcomax + 1
	end
	self.rco = rco
	self.rcomax = 0
	for i,data in pairs(self.rco) do
		self.rcomax = self.rcomax + 1
	end
	self:setProperty("active", 0)
	self:setProperty("stage", 0)
	self.ItemInstance.PotentialIcon = self.image
	self:UpdateIcon()
	self.initfinished = true
end

function DoubleProgressiveItem:GetActive()
	return self:getProperty("active")
end

function DoubleProgressiveItem:GetStage()
	return self:getProperty("stage")
end

function DoubleProgressiveItem:UpdateIcon()
	self.activeImage = self.image
	self.activeImage = ImageReference:FromImageReference(self.activeImage, self.rco[self:GetStage() + 1])
	self.activeImage = ImageReference:FromImageReference(self.activeImage, self.lco[self:GetActive() + 1])
	self.ItemInstance.Icon = self.activeImage
end

function DoubleProgressiveItem:propertyChanged(key, value)
	if self.initfinished then
		self:UpdateIcon()
		if (key == "active") then
			RecentItemsCustomItemHook(self.code[1])
		end
	end
end

-- This allows multiple codes to reference the same item much like it'd do with a non-custom item
function DoubleProgressiveItem:canProvideCode(code)
    for i,data in pairs(self.code) do
		if data == code then
			return true
		end
	end
	return false
end

-- These both recreate looping behavior you'd see in standard progressive items, but this time on both left and right click.
function DoubleProgressiveItem:onLeftClick()
	self:setProperty("active", (self:GetActive() + 1) % self.lcomax)
end

function DoubleProgressiveItem:onRightClick()
	if CurrentlyCapturingLocation then
		CurrentlyCapturingLocation:CaptureHook(self.code[1])
		return
	end
	self:setProperty("stage", (self:GetStage() + 1) % self.rcomax)
end

function DoubleProgressiveItem:save()
	local saveData = {
		["active"] = self:getProperty("active"),
		["stage"] = self:getProperty("stage")
	}
	return saveData
end

function DoubleProgressiveItem:load(data)
	if data then
		self:setProperty("active", data["active"])
		self:setProperty("stage", data["stage"])
		return true
	end
	return false
end

for i,data in pairs(ItemData) do
	local newItem = DoubleProgressiveItem(data["name"], data["code"], data["image"], data["LeftClickOverlays"], data["RightClickOverlays"])
end