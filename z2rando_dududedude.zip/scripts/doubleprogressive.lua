-- Attributes set are similar to what you'd do when defining items in json, just slightly less verbose
local ItemData = {
	{
		["name"] = "Trophy",
		["code"] = {"trophy", "figurine", "statue"},
		["image"] = "images/items/trophy.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
			"overlay|images/overlays/x.png"
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},

	{
		["name"] = "Water of Life",
		["code"] = {"wateroflife", "medicine"},
		["image"] = "images/items/wateroflife.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
			"overlay|images/overlays/x.png"
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},	
	
	{
		["name"] = "Kid",
		["code"] = {"kid", "child"},
		["image"] = "images/items/kid.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
			"overlay|images/overlays/x.png"
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Boots",
		["code"] = {"boots", "boot"},
		["image"] = "images/items/boots.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Candle",
		["code"] = {"candle"},
		["image"] = "images/items/candle.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Cross",
		["code"] = {"cross"},
		["image"] = "images/items/cross.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Flute",
		["code"] = {"flute", "recorder"},
		["image"] = "images/items/flute.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Glove",
		["code"] = {"glove", "gauntlet"},
		["image"] = "images/items/glove.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Hammer",
		["code"] = {"hammer"},
		["image"] = "images/items/hammer.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Magic Key",
		["code"] = {"magickey", "anyjey"},
		["image"] = "images/items/magickey.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Raft",
		["code"] = {"raft"},
		["image"] = "images/items/raft.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Downstab",
		["code"] = {"downstab"},
		["image"] = "images/items/downstab.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Upstab",
		["code"] = {"upstab"},
		["image"] = "images/items/upstab.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Shield",
		["code"] = {"shield"},
		["image"] = "images/spells/shield.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Jump",
		["code"] = {"jump"},
		["image"] = "images/spells/jump.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Life",
		["code"] = {"life"},
		["image"] = "images/spells/life.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Fairy",
		["code"] = {"fairy"},
		["image"] = "images/spells/fairy.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Life",
		["code"] = {"life"},
		["image"] = "images/spells/life.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Fire / Dash",
		["code"] = {"fire"},
		["image"] = "images/spells/fire.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Reflect",
		["code"] = {"reflect"},
		["image"] = "images/spells/reflect.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Spell",
		["code"] = {"spell"},
		["image"] = "images/spells/spell.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Thunder",
		["code"] = {"thunder"},
		["image"] = "images/spells/thunder.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Note for Riverman",
		["code"] = {"rivermannote"},
		["image"] = "images/items/noteforriverman.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Mirror",
		["code"] = {"mirror"},
		["image"] = "images/items/mirror.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Fountain Water",
		["code"] = {"water"},
		["image"] = "images/items/water.png",
		["LeftClickOverlays"] = {
			"@disabled",
			"",
		},
		["RightClickOverlays"] = {
			"",
			"overlay|images/overlays/w.png",
			"overlay|images/overlays/e.png",
			"overlay|images/overlays/dm.png",
			"overlay|images/overlays/mi.png",
		}
	},
	
	{
		["name"] = "Heart Container",
		["code"] = {"heartcontainer"},
		["image"] = "images/items/heartcontainer.png",
		["LeftClickOverlays"] = {
			"overlay|images/overlays/1.png",
			"overlay|images/overlays/2.png",
			"overlay|images/overlays/3.png",
			"overlay|images/overlays/4.png",
			"overlay|images/overlays/5.png",
			"overlay|images/overlays/6.png",
			"overlay|images/overlays/7.png",
			"overlay|images/overlays/8.png"
		},
		["StartActive"] = 3,
		["NoRecentItems"] = true
	},
	
	{
		["name"] = "Magic Container",
		["code"] = {"magiccontainer"},
		["image"] = "images/items/magiccontainer.png",
		["LeftClickOverlays"] = {
			"overlay|images/overlays/1.png",
			"overlay|images/overlays/2.png",
			"overlay|images/overlays/3.png",
			"overlay|images/overlays/4.png",
			"overlay|images/overlays/5.png",
			"overlay|images/overlays/6.png",
			"overlay|images/overlays/7.png",
			"overlay|images/overlays/8.png"
		},
		["StartActive"] = 3,
		["NoRecentItems"] = true
	},
}
-- In this particular case the overlays are the same for all items 
-- I've coded it this way any way for easier customizability in case of use elsewhere later

DoubleProgressiveItem = CustomItem:extend()

-- A double progressive item is a progressive item that has multiple stages for both its left and right click interactions

function DoubleProgressiveItem:init(name,code,image,lco,rco,startactive,startstage,norecentitems)
	self:createItem(name)
	self.name = name
	self.code = code
	self.image = ImageReference:FromPackRelativePath(image)
	self.lco = lco
	self.lcomax = 0
	for i,data in pairs(self.lco) do
		self.lcomax = self.lcomax + 1
	end
	self.rcomax = 0
	if rco then
		self.rco = rco
		for i,data in pairs(self.rco) do
			self.rcomax = self.rcomax + 1
		end
	end
	if startactive then
		self:setProperty("active", startactive)
	else
		self:setProperty("active", 0)
	end
	if startstage then
		self:setProperty("active", startstage)
	else
		self:setProperty("stage", 0)
	end
	self.norecentitems = norecentitems
	self.ItemInstance.PotentialIcon = self.image
	self:UpdateIcon()
	self.initfinished = true
end

function DoubleProgressiveItem:GetActive()
	return self:getProperty("active")
end

function DoubleProgressiveItem:GetStage()
	return self:getProperty("stage")
end

function DoubleProgressiveItem:UpdateIcon()
	self.activeImage = self.image
	if self.rco then
		self.activeImage = ImageReference:FromImageReference(self.activeImage, self.rco[self:GetStage() + 1])
	end
	self.activeImage = ImageReference:FromImageReference(self.activeImage, self.lco[self:GetActive() + 1])
	self.ItemInstance.Icon = self.activeImage
end

function DoubleProgressiveItem:propertyChanged(key, value)
	if self.initfinished then
		self:UpdateIcon()
		if (key == "active") and not (self.norecentitems)then
			RecentItemsCustomItemHook(self.code[1])
		end
	end
end

-- This allows multiple codes to reference the same item much like it'd do with a non-custom item
function DoubleProgressiveItem:canProvideCode(code)
    for i,data in pairs(self.code) do
		if data == code then
			return true
		end
	end
	return false
end

-- These both recreate looping behavior you'd see in standard progressive items, but this time on both left and right click.
function DoubleProgressiveItem:onLeftClick()
	self:setProperty("active", (self:GetActive() + 1) % self.lcomax)
end

function DoubleProgressiveItem:onRightClick()
	if CurrentlyCapturingLocation then
		CurrentlyCapturingLocation:CaptureHook(self.code[1])
		return
	end
	if self.rco then
		self:setProperty("stage", (self:GetStage() + 1) % self.rcomax)
	else
		self:setProperty("active", (self:GetActive() - 1) % self.lcomax)
	end
end

function DoubleProgressiveItem:save()
	local saveData = {
		["active"] = self:getProperty("active"),
		["stage"] = self:getProperty("stage")
	}
	return saveData
end

function DoubleProgressiveItem:load(data)
	if data then
		self:setProperty("active", data["active"])
		self:setProperty("stage", data["stage"])
		return true
	end
	return false
end

for i,data in pairs(ItemData) do
	local newItem = DoubleProgressiveItem(data["name"], data["code"], data["image"], data["LeftClickOverlays"], data["RightClickOverlays"], data["StartActive"], data["StartStage"], data["NoRecentItems"])
end