-- This script handles keeping track of specified recent items
-- When EmoTracker's undo function is used, this script still keeps track of changes made that way as if the item was normally interacted with
-- I consider this a feature, thinking of it as more of a list of recent changes, rather than purely a list of recently acquired items
-- Right-clicking a displayed recent item will remove it from display, shuffling other items in order so there is no gap

-- Variables you'd want to edit to adapt this script to other packs are contained in the top segment.
-- Not all item types are supported. I have done testing with progressive, toggle and progressive_toggle type items; other item types might work but have not been tested

-- Note that modifying a tracker pack to use this script requires some large changes, and if you are not the pack's author might break the pack's future updates
-- If any problems occur with a pack that you have added this script to, make sure to remove any changes you've made to add this script first before reporting problems

-- The amount of different recent items to keep track of
local RecentItemCount = 8

-- A pack relative path to a default image to use. Set to an empty string ("") if you want to have no image. Leaving this entirely blank will break the script.
local DefaultImage = "images/items/pbag.png"

-- Any item you want to track has to have its code set.
-- Not all item types are supported. For composite items use the codes for the component items rather than the code for the composite item itself.

-- List of parameters
-- code: Equal to item code as defined in the pack's item definition .json. All items must have this; other parameters are optional.
-- NoActive: Set to true to not track this item's active state.
-- NoStage: Set to true to not track this item's current stage.
-- image: Defines a pack relative image path to be used instead of the regular item image.
-- NoDisable: Set to true to prevent the item disabled filter from being applied when using a custom image. Does nothing if image is not set for this item.

local RecentItemData = {

	{
		["code"] = "boots"
	},
	
	{
		["code"] = "candle"
	},
	
	{
		["code"] = "cross"
	},
	
	{
		["code"] = "flute"
	},
	
	{
		["code"] = "glove"
	},
	
	{
		["code"] = "hammer"
	},
	
	{
		["code"] = "kid"
	},
	
	{
		["code"] = "magickey"
	},
	
	{
		["code"] = "raft"
	},
	
	{
		["code"] = "trophy"
	},
	
	{
		["code"] = "wateroflife"
	},
	
	{
		["code"] = "town1"
	},
	
	{
		["code"] = "town2"
	},
	
	{
		["code"] = "town3"
	},
	
	{
		["code"] = "town4"
	},
	
	{
		["code"] = "town5"
	},
	
	{
		["code"] = "town6"
	},
	
	{
		["code"] = "town7"
	},
	
	{
		["code"] = "town8"
	},
	
	{
		["code"] = "palace1",
		["NoStage"] = true,
		["image"] = "images/palaces/horsehead.png"
	},
	
	{
		["code"] = "palace2",
		["NoStage"] = true,
		["image"] = "images/palaces/helmethead.png"
	},
	
	{
		["code"] = "palace3",
		["NoStage"] = true,
		["image"] = "images/palaces/rebonack.png"
	},
	
	{
		["code"] = "palace4",
		["NoStage"] = true,
		["image"] = "images/palaces/karock.png"
	},
	
	{
		["code"] = "palace5",
		["NoStage"] = true,
		["image"] = "images/palaces/gooma.png"
	},
	
	{
		["code"] = "palace6",
		["NoStage"] = true,
		["image"] = "images/palaces/barba.png"
	},
	
	{
		["code"] = "palace7",
		["NoStage"] = true,
		["image"] = "images/palaces/thunderbird.png"
	}
}

-- ┌────────────────────────────────────────────┐
-- │ Editing below this line is not recommended │
-- └────────────────────────────────────────────┘

local MostRecentItem
RecentItemCache = {
	["active"] = {},
	["stage"] = {}
}
RecentItemReferences = {}

RecentItem = CustomItem:extend()

function RecentItem:init(index)
	local code = "recentitem" .. index
	self:createItem(code)
	self.code = code
	self.Image = ImageReference:FromPackRelativePath(DefaultImage)
	self.index = index
	self.CurrentItem = 0
	self.ItemInstance.PotentialIcon = self.Image
	
	self:UpdateIcon()
	RecentItemReferences[index] = self
end

function RecentItem:UpdateIcon()
	-- CurrentItem being 0 indicates there is no item to display.
	if self.CurrentItem == 0 then
		self.Image = ImageReference:FromPackRelativePath(DefaultImage)
	else
		-- If CurrentItem does have a value, we need to figure out whether a custom image is specified, and if so whether it is disabled or not
		local item = Tracker:FindObjectForCode(RecentItemData[self.CurrentItem]["code"])
		local data = RecentItemData[self.CurrentItem]
		if data["image"] then
			self.Image = ImageReference:FromPackRelativePath(data["image"])
			-- As of version 2.3.7.2 of EmoTracker, items that are progressive but not toggles will return item.Active as "Active"
			-- In effect this checks if the item is not active, or failing that if it's at stage 0. If so, apply disabled image filter, unless the NoDisable flag exists
			if (not item.Active or (item.Active == "Active" and item.CurrentStage == 0)) and not data["NoDisable"] then
				self.Image = ImageReference:FromImageReference(self.Image, "@disabled")
			end
		else
			self.Image = item.Icon
		end
	end
	self.ItemInstance.Icon = self.Image
end

function RecentItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function RecentItem:providesCode(code)
    return 0
end

-- Right clicking removes the current item, and then moves items so that the new empty spot is at the end.
function RecentItem:onRightClick()
	-- self.index is the identifier number for the item getting right clicked.
	for i=self.index,RecentItemCount do
		if i < RecentItemCount then
			RecentItemReferences[i].CurrentItem = RecentItemReferences[i+1].CurrentItem
		else
			RecentItemReferences[i].CurrentItem = 0
		end
		RecentItemReferences[i]:UpdateIcon()
	end
end

-- The only data we need to save is what the current item is set to
function RecentItem:save()
	local saveData = {
		["CurrentItem"] = self.CurrentItem
	}
	return saveData
end


function RecentItem:load(data)
	if data then
		self.CurrentItem = data["CurrentItem"]
		self:UpdateIcon()
		return true
	end
	return false
end

for i=1,RecentItemCount do
	local newItem = RecentItem(i)
end

DISABLE_RECENTITEM_UPDATES = true

function RecentItemsCheckForUpdates()
	for i,data in pairs(RecentItemData) do
		local item = Tracker:FindObjectForCode(data["code"])
		-- First step is error handling; this way the rest of the script continues even if the data array contains an invalid code
		if item then
			-- Then we skip this if it's either the first update or we're loading a save file
			if not DISABLE_RECENTITEM_UPDATES then
				-- Then I check if the item has changed since the last time it was cached, and I check if the item was flagged to not check a specific property
				if (item.Active ~= RecentItemCache["active"][i] and not data["NoActive"])
				or (item.CurrentStage ~= RecentItemCache["stage"][i] and not data["NoStage"]) then
					RecentItemsUpdate(i)
				end
			end
			RecentItemCache["active"][i] = item.Active
			RecentItemCache["stage"][i] = item.CurrentStage
		else
			print("RecentItems - No item found matching this code: " .. data["code"])
		end
	end
end

-- This hook assumes that if it has been called it needs to update; any handling for when to send updates should be handled on the end of the custom item
-- Custom items do still need to have their code specified within RecentItemData, this is so the script can self-reference to check for duplicates
-- This will also still obey a custom image if it has been set, but is not able to distinguish if the item is active in any way or not
function RecentItemsCustomItemHook(code)
	for i,data in pairs(RecentItemData) do
		if data["code"] == code then
			RecentItemsUpdate(i)
			return
		end
	end
	print("Hook was called but no item found for " .. code .. " in recentitems.lua")
end

function RecentItemsUpdate(item)
	-- This loop figures out if the most recent item is already somewhere in the recent items on display.
	-- This achieves the behavior of never having duplicate items by looking if the item is already set to one of the handlers
	local ItemsToChange = RecentItemCount
	for i=1,RecentItemCount do
		if RecentItemReferences[i].CurrentItem == item then
			ItemsToChange = i
			break
		end
	end

	-- This loop goes backwards through the amount of items we're changing
	for i=1,ItemsToChange do
		-- If we've reached the end of the loop, update the first item
		if i == ItemsToChange then
			RecentItemReferences[1].CurrentItem = item
		-- Otherwise, change an item into the one before it, making space for the new item
		else
			RecentItemReferences[(ItemsToChange+1) - i].CurrentItem = RecentItemReferences[(ItemsToChange) - i].CurrentItem
		end
		RecentItemReferences[(ItemsToChange+1) - i]:UpdateIcon()
	end
end

RecentItemsCheckForUpdates()

DISABLE_RECENTITEM_UPDATES = false

function tracker_on_begin_loading_save_file()
    DISABLE_RECENTITEM_UPDATES = true
end

-- We do a call to rebuild the item cache here so that it has the item data from the save file after loading is done.
function tracker_on_finish_loading_save_file()
	BuildRecentItemCache()
    DISABLE_RECENTITEM_UPDATES = false
end

function tracker_on_accessibility_updated()
	if not DISABLE_RECENTITEM_UPDATES then
		RecentItemsCheckForUpdates()
	end
end