-- Attributes set are similar to what you'd do when defining items in json, just slightly less verbose
local ItemData = {
	{
		["name"] = "Palace 1 Item",
		["code"] = {"palace1item", "desertpalaceitem", "parapapalaceitem"},
		["image"] = "images/palaces/palace1item.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		},
		["MaxCount"] = 2
	},
	
	{
		["name"] = "Palace 2 Item",
		["code"] = {"palace2item", "swamppalaceitem", "midoripalaceitem"},
		["image"] = "images/palaces/palace2item.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		},
		["MaxCount"] = 3
	},
	
	{
		["name"] = "Palace 3 Item",
		["code"] = {"palace3item", "islandpalaceitem"},
		["image"] = "images/palaces/palace3item.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		},
		["MaxCount"] = 2
	},
	
	{
		["name"] = "Palace 4 Item",
		["code"] = {"palace4item", "mazepalaceitem"},
		["image"] = "images/palaces/palace4item.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		},
		["MaxCount"] = 3
	},
	
	{
		["name"] = "Palace 5 Item",
		["code"] = {"palace5item", "oceanpalaceitem", "seapalaceitem"},
		["image"] = "images/palaces/palace5item.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		},
		["MaxCount"] = 4
	},
	
	{
		["name"] = "Palace 6 Item",
		["code"] = {"palace6item", "hiddenpalaceitem"},
		["image"] = "images/palaces/palace6item.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		},
		["MaxCount"] = 4
	},
	
	{
		["name"] = "East PBag Cave",
		["code"] = {"eastpbagcave"},
		["image"] = "images/itemlocations/eastpbagcave.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "East PBag Cave 2",
		["code"] = {"eastpbagcave2"},
		["image"] = "images/itemlocations/eastpbagcave2.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Hammer Cave",
		["code"] = {"hammercave"},
		["image"] = "images/itemlocations/hammercave.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Heart Container Cave",
		["code"] = {"heartcontainercave", "hccave"},
		["image"] = "images/itemlocations/heartcontainercave.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Heart Container Desert",
		["code"] = {"heartcontainerdesert", "hcdesert"},
		["image"] = "images/itemlocations/heartcontainerdesert.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Heart Container Sea",
		["code"] = {"heartcontainersea", "hcsea"},
		["image"] = "images/itemlocations/heartcontainersea.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Heart Container Grass",
		["code"] = {"heartcontainergrass", "hcgrass"},
		["image"] = "images/itemlocations/heartcontainergrass.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Kid Maze",
		["code"] = {"kidmaze", "childmaze"},
		["image"] = "images/itemlocations/kidmaze.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Magic Container Boulder",
		["code"] = {"magiccontainerboulder", "mcboulder"},
		["image"] = "images/itemlocations/magiccontainerboulder.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Magic Container Cave",
		["code"] = {"magiccontainercave", "mccave"},
		["image"] = "images/itemlocations/magiccontainercave.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Magic Container Maze",
		["code"] = {"magiccontainermaze", "mcmaze"},
		["image"] = "images/itemlocations/magiccontainermaze.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Magic Container New Kasuto",
		["code"] = {"magiccontainernewkasuto", "mcnewkasuto", "magiccontainertown", "mctown"},
		["image"] = "images/itemlocations/magiccontainernewkasuto.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Magic key New Kasuto",
		["code"] = {"magickeynewkasuto", "magickeytown", "anykeynewkasuto", "anykeytown"},
		["image"] = "images/itemlocations/magickeynewkasuto.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Trophy Cave",
		["code"] = {"trophycave", "figurinecave", "statuecave"},
		["image"] = "images/itemlocations/trophycave.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Water of Life Cave",
		["code"] = {"wateroflifecave", "medicinecave"},
		["image"] = "images/itemlocations/wateroflifecave.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "West PBag Cave",
		["code"] = {"westpbagcave"},
		["image"] = "images/itemlocations/westpbagcave.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Rauru Old Man",
		["code"] = {"rauruoldman"},
		["image"] = "images/itemlocations/shieldoldman.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Ruto Old Man",
		["code"] = {"rutooldman"},
		["image"] = "images/itemlocations/jumpoldman.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Saria Old Man",
		["code"] = {"sariaoldman"},
		["image"] = "images/itemlocations/lifeoldman.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Mido Old Man",
		["code"] = {"midooldman"},
		["image"] = "images/itemlocations/fairyoldman.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Nabooru Old Man",
		["code"] = {"nabooruoldman"},
		["image"] = "images/itemlocations/fireoldman.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Darunia Old Man",
		["code"] = {"daruniaoldman"},
		["image"] = "images/itemlocations/reflectoldman.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "New Kasuto Old Man",
		["code"] = {"newkasutooldman"},
		["image"] = "images/itemlocations/spelloldman.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Kasuto Old Man",
		["code"] = {"kasutooldman"},
		["image"] = "images/itemlocations/thunderoldman.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Bagu",
		["code"] = {"bagu"},
		["image"] = "images/itemlocations/bagu.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Down Stab Man",
		["code"] = {"downstabman"},
		["image"] = "images/itemlocations/downstabman.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Up Stab Man",
		["code"] = {"upstabman"},
		["image"] = "images/itemlocations/upstabman.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Saria Table",
		["code"] = {"sariatable"},
		["image"] = "images/itemlocations/sariatable.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Nabooru Fountain",
		["code"] = {"naboorufountain"},
		["image"] = "images/itemlocations/naboorufountain.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
}

-- These are the items that can be displayed on a location item, in this randomizer's case the 23 major items that NPCs can give hints for
local CapturableItems = {
	["trophy"] = "overlay|images/items/trophy.png",
	["wateroflife"] = "overlay|images/items/wateroflife.png",
	["kid"] = "overlay|images/items/kid.png",
	["boots"] = "overlay|images/items/boots.png",
	["candle"] = "overlay|images/items/candle.png",
	["cross"] = "overlay|images/items/cross.png",
	["flute"] = "overlay|images/items/flute.png",
	["glove"] = "overlay|images/items/glove.png",
	["hammer"] = "overlay|images/items/hammer.png",
	["magickey"] = "overlay|images/items/magickey.png",
	["raft"] = "overlay|images/items/raft.png",
	["downstab"] = "overlay|images/items/downstab.png",
	["upstab"] = "overlay|images/items/upstab.png",
	["shield"] = "overlay|images/spells/shield.png",
	["jump"] = "overlay|images/spells/jump.png",
	["life"] = "overlay|images/spells/life.png",
	["fairy"] = "overlay|images/spells/fairy.png",
	["fire"] = "overlay|images/spells/fire.png",
	["reflect"] = "overlay|images/spells/reflect.png",
	["spell"] = "overlay|images/spells/spell.png",
	["thunder"] = "overlay|images/spells/thunder.png",
	["rivermannote"] = "overlay|images/items/noteforriverman.png",
	["mirror"] = "overlay|images/items/mirror.png",
	["water"] = "overlay|images/items/water.png",
}

local NumberOverlays = {
	"overlay|images/palaces/1.png",
	"overlay|images/palaces/2.png",
	"overlay|images/palaces/3.png",
	"overlay|images/palaces/4.png"
}

local RightClickOverlay = "overlay|images/overlays/bag.png"

local CaptureLocationCache = {}


CaptureLocationItem = CustomItem:extend()

-- These are effectively simple toggles on left click, that can be set to grab specific other items on right click

function CaptureLocationItem:init(name,code,image,lco,maxcount)
	self:createItem(name)
	self.name = name
	self.code = code
	self.image = ImageReference:FromPackRelativePath(image)
	self.lco = lco
	self.lcomax = 0
	for i,data in pairs(self.lco) do
		self.lcomax = self.lcomax + 1
	end
	self.maxcount = maxcount
	self:setProperty("active", 0)
	self:setProperty("item", false)
	self:setProperty("itemcount", 1)
	self.ItemInstance.PotentialIcon = self.image
	self:UpdateIcon()
	CaptureLocationCache[code[1]] = self
	self.initfinished = true
end

function CaptureLocationItem:GetActive()
	return self:getProperty("active")
end

function CaptureLocationItem:GetItem()
	return self:getProperty("item")
end

function CaptureLocationItem:GetCount()
	return self:getProperty("itemcount")
end

function CaptureLocationItem:UpdateIcon()
	self.activeImage = self.image
	if CurrentlyCapturingLocation == self then
		self.activeImage = ImageReference:FromImageReference(self.activeImage, RightClickOverlay)
	elseif self:GetItem() then
		self.activeImage = ImageReference:FromImageReference(self.activeImage, CapturableItems[self:GetItem()])
	end
	if self.maxcount and self:GetActive() < 1 then
		local count = self:GetCount()
		self.activeImage = ImageReference:FromImageReference(self.activeImage, NumberOverlays[count])
	end
	self.activeImage = ImageReference:FromImageReference(self.activeImage, self.lco[self:GetActive() + 1])
	self.ItemInstance.Icon = self.activeImage
end

function CaptureLocationItem:propertyChanged(key, value)
	if self.initfinished then
		self:UpdateIcon()
	end
end

-- This allows multiple codes to reference the same item much like it'd do with a non-custom item
function CaptureLocationItem:canProvideCode(code)
    for i,data in pairs(self.code) do
		if data == code then
			return true
		end
	end
	return false
end

-- These both recreate looping behavior you'd see in standard progressive items
function CaptureLocationItem:onLeftClick()
	local count = self:GetCount()
	if count > 1 then
		self:setProperty("itemcount", count - 1)
	else
		self:setProperty("active", (self:GetActive() + 1) % self.lcomax)
	end
end

function CaptureLocationItem:onRightClick()
	if CurrentlyCapturingLocation == self then
		CurrentlyCapturingLocation = nil
		self:UpdateIcon()
		return
	elseif self:GetItem() then
		self:setProperty("item", false)
		return
	elseif CurrentlyCapturingLocation then
		CurrentlyCapturingLocation:onRightClick()
	end
	CurrentlyCapturingLocation = self
	self:UpdateIcon()
end

function CaptureLocationItem:CaptureHook(code)
	CurrentlyCapturingLocation = nil
	self:setProperty("item", code)
end

function CaptureLocationItem:IncrementCountHook()
	local count = self:GetCount()
	if count < self.maxcount then
		if self:GetActive() == 1 then
			self:setProperty("active",0)
		else
			self:setProperty("itemcount",count + 1)
		end
	end
end

function CaptureLocationItem:save()
	local saveData = {
		["active"] = self:getProperty("active"),
		["item"] = self:getProperty("item"),
		["itemcount"] = self:getProperty("itemcount")
	}
	return saveData
end

function CaptureLocationItem:load(data)
	if data then
		self:setProperty("active", data["active"])
		self:setProperty("item", data["item"])
		self:setProperty("itemcount", data["itemcount"])
		return true
	end
	return false
end

-- IncrementerItems add a visible number to palace items. These are created for any locations with a defined MaxCount
IncrementerItem = CustomItem:extend()

function IncrementerItem:init(name,code)
	self:createItem(name .. " Incrementer")
	self.name = name .. " Incrementer"
	self.code = code[1] .. "incrementer"
	self.linkeditem = code[1]
	self.image = ImageReference:FromPackRelativePath("images/palaces/plus.png")	
	self.ItemInstance.PotentialIcon = self.image
	self:updateIcon()
end

function IncrementerItem:updateIcon()
	self.activeImage = self.image
	self.ItemInstance.Icon = self.activeImage
end

function IncrementerItem:onLeftClick()
	CaptureLocationCache[self.linkeditem]:IncrementCountHook()
end

function IncrementerItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function IncrementerItem:providesCode(code)
    if code == self.code and self.Active then
        return 1
    end
    return 0
end

function IncrementerItem:save()
end

for i,data in pairs(ItemData) do
	local newItem = CaptureLocationItem(data["name"], data["code"], data["image"], data["LeftClickOverlays"], data["MaxCount"])
	if data["MaxCount"] then
		local newItem = IncrementerItem(data["name"], data["code"])
	end
end