-- Attributes set are similar to what you'd do when defining items in json, just slightly less verbose
local ItemData = {
	{
		["name"] = "Palace 1 Item",
		["code"] = {"palace1item", "desertpalaceitem", "parapapalaceitem"},
		["image"] = "images/palaces/palace1item.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Palace 2 Item",
		["code"] = {"palace2item", "swamppalaceitem", "midoripalaceitem"},
		["image"] = "images/palaces/palace2item.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Palace 3 Item",
		["code"] = {"palace3item", "islandpalaceitem"},
		["image"] = "images/palaces/palace3item.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Palace 4 Item",
		["code"] = {"palace4item", "mazepalaceitem"},
		["image"] = "images/palaces/palace4item.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Palace 5 Item",
		["code"] = {"palace5item", "oceanpalaceitem", "seapalaceitem"},
		["image"] = "images/palaces/palace5item.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	},
	
	{
		["name"] = "Palace 6 Item",
		["code"] = {"palace6item", "hiddenpalaceitem"},
		["image"] = "images/palaces/palace1item.png",
		["LeftClickOverlays"] = {
			"",
			"overlay|images/overlays/x.png"
		}
	}
}

-- These are the items that can be displayed on a location item, in this randomizer's case the 11 major items that NPCs can give hints for
local CapturableItems = {
	["trophy"] = "overlay|images/items/trophy.png",
	["wateroflife"] = "overlay|images/items/wateroflife.png",
	["kid"] = "overlay|images/items/kid.png",
	["boots"] = "overlay|images/items/boots.png",
	["candle"] = "overlay|images/items/candle.png",
	["cross"] = "overlay|images/items/cross.png",
	["flute"] = "overlay|images/items/flute.png",
	["glove"] = "overlay|images/items/glove.png",
	["hammer"] = "overlay|images/items/hammer.png",
	["magickey"] = "overlay|images/items/magickey.png",
	["raft"] = "overlay|images/items/raft.png",
}

local RightClickOverlay = "overlay|images/overlays/bag.png"


CaptureLocationItem = CustomItem:extend()

-- These are effectively simple toggles on left click, that can be set to grab specific other items on right click

function CaptureLocationItem:init(name,code,image,lco,rco)
	self:createItem(name)
	self.name = name
	self.code = code
	self.image = ImageReference:FromPackRelativePath(image)
	self.lco = lco
	self.lcomax = 0
	for i,data in pairs(self.lco) do
		self.lcomax = self.lcomax + 1
	end
	self:setProperty("active", 0)
	self:setProperty("item", nil)
	self.ItemInstance.PotentialIcon = self.image
	self:UpdateIcon()
	self.initfinished = true
end

function CaptureLocationItem:GetActive()
	return self:getProperty("active")
end

function CaptureLocationItem:GetItem()
	return self:getProperty("item")
end

function CaptureLocationItem:UpdateIcon()
	self.activeImage = self.image
	if CurrentlyCapturingLocation == self then
		self.activeImage = ImageReference:FromImageReference(self.activeImage, RightClickOverlay)
	elseif self:GetItem() then
		self.activeImage = ImageReference:FromImageReference(self.activeImage, CapturableItems[self:GetItem()])
	end
	self.activeImage = ImageReference:FromImageReference(self.activeImage, self.lco[self:GetActive() + 1])
	self.ItemInstance.Icon = self.activeImage
end

function CaptureLocationItem:propertyChanged(key, value)
	if self.initfinished then
		self:UpdateIcon()
	end
end

-- This allows multiple codes to reference the same item much like it'd do with a non-custom item
function CaptureLocationItem:canProvideCode(code)
    for i,data in pairs(self.code) do
		if data == code then
			return true
		end
	end
	return false
end

-- These both recreate looping behavior you'd see in standard progressive items
function CaptureLocationItem:onLeftClick()
	self:setProperty("active", (self:GetActive() + 1) % self.lcomax)
end

function CaptureLocationItem:onRightClick()
	if self:GetItem() then
		self:setProperty("item", nil)
		return
	elseif CurrentlyCapturingLocation == self then
		CurrentlyCapturingLocation = nil
		self:UpdateIcon()
		return
	elseif CurrentlyCapturingLocation then
		CurrentlyCapturingLocation:onRightClick()
	end
	CurrentlyCapturingLocation = self
	self:UpdateIcon()
end

function CaptureLocationItem:CaptureHook(code)
	CurrentlyCapturingLocation = nil
	self:setProperty("item", code)
end

function CaptureLocationItem:save()
	local saveData = {
		["active"] = self:getProperty("active"),
		["item"] = self:getProperty("item")
	}
	return saveData
end

function CaptureLocationItem:load(data)
	if data then
		self:setProperty("active", data["active"])
		self:setProperty("item", data["item"])
		return true
	end
	return false
end

for i,data in pairs(ItemData) do
	local newItem = CaptureLocationItem(data["name"], data["code"], data["image"], data["LeftClickOverlays"])
end