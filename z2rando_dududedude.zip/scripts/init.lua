Tracker:AddItems("items/common.json")
Tracker:AddItems("items/locations.json")
Tracker:AddItems("items/spells.json")

if not (string.find(Tracker.ActiveVariantUID, "mapping")) then
	Tracker:AddLayouts("layouts/tracker.json")
else
	Tracker:AddItems("items/mapping.json")  
	Tracker:AddLayouts("layouts/tracker_mapping.json")
end

Tracker:AddLayouts("layouts/broadcast.json")
Tracker:AddLayouts("layouts/capture.json")