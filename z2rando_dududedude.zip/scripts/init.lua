Tracker:AddItems("items/common.json")
Tracker:AddItems("items/locations.json")
Tracker:AddItems("items/palaces.json")
Tracker:AddItems("items/spells.json")
Tracker:AddItems("items/connectors.json")
ScriptHost:LoadScript("scripts/class.lua")
ScriptHost:LoadScript("scripts/custom_item.lua")
ScriptHost:LoadScript("scripts/doubleprogressive.lua")
ScriptHost:LoadScript("scripts/capturelocations.lua")

if not string.find(Tracker.ActiveVariantUID, "spellshuffle") then
	Tracker:AddLayouts("layouts/sharedgrid.json")
else
	Tracker:AddLayouts("layouts/spellshufflegrid.json")
end

if not string.find(Tracker.ActiveVariantUID, "mapping") then
	Tracker:AddLayouts("layouts/tracker.json")
else
	if string.find(Tracker.ActiveVariantUID, "old") then
		Tracker:AddItems("items/oldmapping.json")
		Tracker:AddLayouts("layouts/oldmapgrid.json")
	else
		ScriptHost:LoadScript("scripts/compactmap.lua")
		Tracker:AddLayouts("layouts/mapgrid.json")
	end
	Tracker:AddLayouts("layouts/tracker_mapping.json")
end

-- This load order is a little messy but starting recentitems before starting the maps severely increases load times
-- The script itself isn't needed until the broadcast layouts are loaded.

ScriptHost:LoadScript("scripts/recentitems.lua")

if not string.find(Tracker.ActiveVariantUID, "spellshuffle") then
	Tracker:AddLayouts("layouts/broadcast.json")
else
	Tracker:AddLayouts("layouts/spellshufflebroadcast.json")
end

Tracker:AddLayouts("layouts/capture.json")