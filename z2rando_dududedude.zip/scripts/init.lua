Tracker:AddItems("items/common.json")
Tracker:AddItems("items/locations.json")
Tracker:AddItems("items/palaces.json")
Tracker:AddItems("items/spells.json")
ScriptHost:LoadScript("scripts/class.lua")
ScriptHost:LoadScript("scripts/custom_item.lua")
ScriptHost:LoadScript("scripts/doubleprogressive.lua")
ScriptHost:LoadScript("scripts/recentitems.lua")
Tracker:AddLayouts("layouts/sharedgrid.json")

if not string.find(Tracker.ActiveVariantUID, "mapping") then
	Tracker:AddLayouts("layouts/tracker.json")
else
	if string.find(Tracker.ActiveVariantUID, "old") then
		Tracker:AddItems("items/oldmapping.json")
		Tracker:AddLayouts("layouts/oldmapgrid.json")
	else
		ScriptHost:LoadScript("scripts/compactmap.lua")
		Tracker:AddLayouts("layouts/mapgrid.json")
	end
	Tracker:AddLayouts("layouts/tracker_mapping.json")
end

Tracker:AddLayouts("layouts/broadcast.json")
Tracker:AddLayouts("layouts/capture.json")