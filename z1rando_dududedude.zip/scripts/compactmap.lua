PaletteCodes = {
	-- Dungeons
	"palettelevel1",
	"palettelevel2",
	"palettelevel3",
	"palettelevel4",
	"palettelevel5",
	"palettelevel6",
	"palettelevel7",
	"palettelevel8",
	"palettelevel9",
	"palettelevelunknown",
	
	-- Sword Caves
	"palettewoodswordcave",
	"palettewhiteswordcave",
	"palettemagicswordcave",
	
	-- Free Stuff
	"paletterupees",
	"palettetakeany",
	
	-- Warps
	"palettewarp1",
	"palettewarp2",
	"palettewarp3",
	"palettewarp4",
	
	-- Shops
	"paletteshoparrow",
	"paletteshopbait",
	"paletteshopbluering",
	"paletteshopbomb",
	"paletteshopcandle",
	"paletteshophint",
	"paletteshopkey",
	"paletteshopmagicshield",
	"paletteshopmedicine",
	"palettemmg"
}
CurrentPalette = 0

function UpdatePalette()
	for i,code in pairs(PaletteCodes) do
		local item = Tracker:FindObjectForCode(code)
		-- Did the user disable the currently selected palette, if so set stored value to 0
		if i == CurrentPalette and not item.Active then
			CurrentPalette = 0
		-- Check to see if an activated palette that isn't the one we stored is active
		elseif i ~= CurrentPalette and item.Active then
			-- If there was a previously selected palette still active, disable that one
			if CurrentPalette ~= 0 then
				local oldpalette = Tracker:FindObjectForCode(PaletteCodes[CurrentPalette])
				oldpalette.Active = false
			end
			CurrentPalette = i
		end
	end
end

LoadInProgress = false
CompactMapCache = {}
CompactMapItems = {}
-- Concatenation isn't particularly efficient, so we cache all 128 item codes once on init to help tracker performance
for i = 1,128 do
	CompactMapItems[i] = Tracker:FindObjectForCode("compactmap" .. i)
end

function UpdateCompactMap()
	for i,item in pairs(CompactMapItems) do
		-- Did the user left-click a part of our compact map
		if item.CurrentStage ~= CompactMapCache[i] then
			-- This gives the desired controls; left click once to set to current palette,
			-- if that palette is already set to this spot on the map, blank it out instead
			if CompactMapCache[i] ~= CurrentPalette then
				CompactMapCache[i] = CurrentPalette
			else
				CompactMapCache[i] = 0
			end
			item.CurrentStage = CompactMapCache[i]
		end
	end
end

function RebuildMapCache()
	for i,item in pairs(CompactMapItems) do
		CompactMapCache[i] = item.CurrentStage
	end
end

function tracker_on_begin_loading_save_file()
	LoadInProgress = true
end

function tracker_on_finish_loading_save_file()
	RebuildMapCache()
	LoadInProgress = false
end

function CheckSettings()
	StageForOverlays = 0
	if Tracker:FindObjectForCode("queststate").Active then
		StageForOverlays = StageForOverlays + 1
	end
	if Tracker:FindObjectForCode("mirrored").Active then
		StageForOverlays = StageForOverlays + 2
	end
	if Tracker:FindObjectForCode("mixedquest").Active then
		StageForOverlays = StageForOverlays + 4
	end
end

OverlayCodes = {
	[ "caveoverlay"] = "placeholdercave",
	[ "recorderoverlay" ] = "recorder",
	[ "bomboverlay"] = "bomb",
	[ "candleoverlay" ] = "placeholdercandle",
	[ "powerbraceletoverlay" ] = "powerbracelet"
}

function UpdateOverlays()
	local item = Tracker:FindObjectForCode("placeholdercandle")
	if Tracker:FindObjectForCode("candle").CurrentStage > 0 then
		item.Active = true
	else
		item.Active = false
	end
	for overlay,requirement in pairs(OverlayCodes) do
		local target = Tracker:FindObjectForCode(overlay)
		local item = Tracker:FindObjectForCode(requirement)
		target.CurrentStage = StageForOverlays
		target.Active = item.Active
	end
end

function tracker_on_accessibility_updated()
	if LoadInProgress then
		return
	end
	UpdateCompactMap()
	UpdatePalette()
	CheckSettings()
	UpdateOverlays()
end