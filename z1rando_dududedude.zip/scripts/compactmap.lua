-- The default image a compact map square will get set to
BlankImage = "images/compactlocations/blank.png"

-- The image to set to on right click, for this pack it's the x on a gray background
OnRightClickMapImage = "images/compactlocations/nothing.png"

-- The amount of separate compact map squares to create, will be created as compactmap(one through set count)
CompactMapLocationCount = 128

-- Define items to add to the palette by adding the necesarry data here
-- Attributes set are similar to what you'd do when defining items in json, just slightly less verbose
PaletteData = {
	-- Dungeons
	{
		["name"] = "Level 1",
		["code"] = "palettelevel1",
		["image"] = "images/compactlocations/levelone.png"
	},
	
	{
		["name"] = "Level 2",
		["code"] = "palettelevel2",
		["image"] = "images/compactlocations/leveltwo.png"
	},

	{
		["name"] = "Level 3",
		["code"] = "palettelevel3",
		["image"] = "images/compactlocations/levelthree.png"
	},
	
	{
		["name"] = "Level 4",
		["code"] = "palettelevel4",
		["image"] = "images/compactlocations/levelfour.png"
	},
	
	{
		["name"] = "Level 5",
		["code"] = "palettelevel5",
		["image"] = "images/compactlocations/levelfive.png"
	},	
	
	{
		["name"] = "Level 6",
		["code"] = "palettelevel6",
		["image"] = "images/compactlocations/levelsix.png"
	},

	{
		["name"] = "Level 7",
		["code"] = "palettelevel7",
		["image"] = "images/compactlocations/levelseven.png"
	},
	
	{
		["name"] = "Level 8",
		["code"] = "palettelevel8",
		["image"] = "images/compactlocations/leveleight.png"
	},

	{
		["name"] = "Level 9",
		["code"] = "palettelevel9",
		["image"] = "images/compactlocations/levelnine.png"
	},
	
	{
		["name"] = "Level Unknown",
		["code"] = "palettelevelunknown",
		["image"] = "images/compactlocations/levelunknown.png"
	},
	
	-- Sword Caves
	{
		["name"] = "Wood Sword Cave",
		["code"] = "palettewoodswordcave",
		["image"] = "images/compactlocations/woodswordcave.png"
	},
	
	{
		["name"] = "White Sword Cave",
		["code"] = "palettewhiteswordcave",
		["image"] = "images/compactlocations/whiteswordcave.png"
	},

	{
		["name"] = "Magic Sword Cave",
		["code"] = "palettemagicswordcave",
		["image"] = "images/compactlocations/magicswordcave.png"
	},
	
	-- Free Stuff
	{
		["name"] = "Secret To Everybody",
		["code"] = "paletterupees",
		["image"] = "images/compactlocations/rupees.png"
	},

	{
		["name"] = "Take Any",
		["code"] = "palettetakeany",
		["image"] = "images/compactlocations/takeany.png"
	},
		
	-- Warps
	{
		["name"] = "Warp 1",
		["code"] = "palettewarp1",
		["image"] = "images/compactlocations/warpone.png"
	},
	
	{
		["name"] = "Warp 2",
		["code"] = "palettewarp2",
		["image"] = "images/compactlocations/warptwo.png"
	},
	
	{
		["name"] = "Warp 3",
		["code"] = "palettewarp3",
		["image"] = "images/compactlocations/warpthree.png"
	},
	
	{
		["name"] = "Warp 4",
		["code"] = "palettewarp4",
		["image"] = "images/compactlocations/warpfour.png"
	},
	
	-- Shops
	{
		["name"] = "Arrow Shop",
		["code"] = "paletteshoparrow",
		["image"] = "images/compactlocations/shoparrow.png"
	},
	
	{
		["name"] = "Bait Shop",
		["code"] = "paletteshopbait",
		["image"] = "images/compactlocations/shopbait.png"
	},
	
	{
		["name"] = "Blue Ring Shop",
		["code"] = "paletteshopbluering",
		["image"] = "images/compactlocations/shopbluering.png"
	},
	
	{
		["name"] = "Bomb Shop",
		["code"] = "paletteshopbomb",
		["image"] = "images/compactlocations/shopbomb.png"
	},
	
	{
		["name"] = "Candle Shop",
		["code"] = "paletteshopcandle",
		["image"] = "images/compactlocations/shopcandle.png"
	},
	
	{
		["name"] = "Hint Shop",
		["code"] = "paletteshophint",
		["image"] = "images/compactlocations/shophint.png"
	},
	
	{
		["name"] = "Key Shop",
		["code"] = "paletteshopkey",
		["image"] = "images/compactlocations/shopkey.png"
	},
	
	{
		["name"] = "Magic Shield Shop",
		["code"] = "paletteshopmagicshield",
		["image"] = "images/compactlocations/shopmagicshield.png"
	},
	
	{
		["name"] = "Medicine Shop",
		["code"] = "paletteshopmedicine",
		["image"] = "images/compactlocations/shopmedicine.png"
	},
	
	{
		["name"] = "Money Making Game",
		["code"] = "palettemmg",
		["image"] = "images/compactlocations/moneymakinggame.png"
	},
}

PaletteItem = class(CustomItem)

-- PaletteItems are the mutually exclusive items that you use to control what you're putting on a map square
-- There are no properties used on this one since we do not want this item to change by using undo
-- In addition there is no handling for saving and loading since we want it to return to its default state if a save is loaded
-- Extra variables:
-- self.imagePath - Stores the image path used on init for setting the map square

function PaletteItem:init(name,code,image)
	self:createItem(name)
	self.code = code
	self.Active = false
	self.activeImage = ImageReference:FromPackRelativePath(image)
	self.imagePath = image
	self.disabledImage = ImageReference:FromImageReference(self.activeImage, "@disabled")
	self.ItemInstance.PotentialIcon = self.activeImage
	
	self:UpdateIcon()
end

function PaletteItem:UpdateIcon()
	if self.Active then
		self.ItemInstance.Icon = self.activeImage
	else
		self.ItemInstance.Icon = self.disabledImage
	end
end

function PaletteItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function PaletteItem:providesCode(code)
    if code == self.code and self.Active then
        return 1
    end
    return 0
end

function PaletteItem:onLeftClick()
	-- Disable the currently selected palette item if there is one
	if CurrentPalette then
		CurrentPalette.Active = false
		CurrentPalette:UpdateIcon()
	end
	-- The rest here we can just do regardless of if the item is active already or not
	-- "CurrentPalette = self" stores the relative link to our current item for later use
	CurrentPalette = self
    self.Active = true
	-- Since we're not using setProperty we also can't use PropertyChanged() and so have to just push the icon update here.
	self:UpdateIcon()
end

function PaletteItem:onRightClick()
	-- We do need to double check that the user isn't right-clicking another palette item
	-- So check if it's active first before we nil the palette
	if self.Active then
		CurrentPalette = nil
	end
    self.Active = false
	-- Since we're not using setProperty we also can't use PropertyChanged() and so have to just push the icon update here
	self:UpdateIcon()
end

-- Since we're not interested in saving palette state, we make the save function return nothing instead of the default empty table
function PaletteItem:save()
end

for i,data in pairs(PaletteData) do
	local newItem = PaletteItem(data["name"], data["code"], data["image"])
end

-- CompactMapItem is the squares that make up the map
-- Properties:
-- active - boolean if item is active or not
-- image - string storing the image path for what this map square is currently set to
-- Variables:
-- self.activeImage - The image to be set to when the square is right-clicked
-- self.disabledImage - The image that the square has currently been set through by left-clicking

CompactMapItem = class(CustomItem)

-- I'm using more variables here for easy customization
-- Additionally codes are incremented through passing the i value of a for loop
-- We don't need any other variables passed on since the rest is fixed information
function CompactMapItem:init(iteration)
	self:createItem("Compact Map")
    self.code = "compactmap" .. iteration
	self:setProperty("active", false)
	self:setProperty("image", BlankImage)
    self.activeImage = ImageReference:FromPackRelativePath(OnRightClickMapImage)
    self.disabledImage = ImageReference:FromPackRelativePath(self:getImage())
    self.ItemInstance.PotentialIcon = self.activeImage

    self:updateIcon()
end

function CompactMapItem:getActive()
	return self:getProperty("active")
end

function CompactMapItem:getImage()
	return self:getProperty("image")
end

function CompactMapItem:updateIcon()
	if self:getActive() then
		self.ItemInstance.Icon = self.activeImage
	else
		self.ItemInstance.Icon = self.disabledImage
	end
end

function CompactMapItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function CompactMapItem:providesCode(code)
    if code == self.code and self.getActive() then
        return 1
    end
    return 0
end

-- Desired controls here are click to set selected palette as image, left-clicking again with same palette will revert back to blank
function CompactMapItem:onLeftClick()
	-- Do we have a palette item active
	if CurrentPalette then
		-- If it's already set to this square, set it to blank instead
		if self:getImage() == CurrentPalette.imagePath then
			self:setProperty("image", BlankImage)
		-- Otherwise, set it to the image path of our active palette
		else
			self:setProperty("image", CurrentPalette.imagePath)
		end
	-- If there is nothing selected right now, we also blank the clicked square
	else
		self:setProperty("image", BlankImage)
	end
end

-- Right clicking swaps between the item set as OnRightClickMapImage showing or not
-- Worth mentioning that right-clicking purposefully doesn't delete the underlying item
-- It's friendlier for misclicks that way
function CompactMapItem:onRightClick()
	if self:getActive() then
		self:setProperty("active", false)
	else
		self:setProperty("active", true)
	end
end

function CompactMapItem:propertyChanged(key, value)
	-- If the property changed was the image, we need to update the image path used
	if key == "image" then
		self.disabledImage = ImageReference:FromPackRelativePath(value)
	end
    self:updateIcon()
end

-- Unlike the PaletteItems we do save the properties we've set here, we want them to show up again if someone saves/loads
function CompactMapItem:save()
    local saveData = {
		["active"] = self:getActive(),
		["imagePath"] = self:getImage()
	}
    return saveData
end

-- Loading is fairly minimalistic, just need to make certain we don't overwrite defaults if there is no data to be put in
function CompactMapItem:load(data)
    if data ~= nil then
        self:setProperty("active", data["active"])
		self:setProperty("image", data["imagePath"])
	end
    return true
end

for i=1,CompactMapLocationCount do
	local newItem = CompactMapItem(i)
end