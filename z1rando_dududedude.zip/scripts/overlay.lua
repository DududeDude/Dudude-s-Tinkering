-- OverlayItems are what make the colored dots appear as you collect specific items
OverlayItem = class(CustomItem)

-- This is effectively [overlaycode] = requireditemcode, for automated handling these expect the items to be simple toggles
OverlayCodes = {
	[ "caveoverlay"] = "placeholdercave",
	[ "recorderoverlay" ] = "recorder",
	[ "bomboverlay"] = "bomb",
	[ "candleoverlay" ] = "candle",
	[ "powerbraceletoverlay" ] = "powerbracelet"
}

-- These on the other hand are the fuller definitions for the overlays themselves. Similar to defining the code and stages in a progressive item
OverlayData = {
	[ "caveoverlay" ] = {
		"images/compactmaps/overlays/openz1q1.png",
		"images/compactmaps/overlays/openz1q2.png",
		"images/compactmaps/overlays/openz1q1m.png",
		"images/compactmaps/overlays/openz1q2m.png",
		"images/compactmaps/overlays/openz1q1mix.png",
		"images/compactmaps/overlays/openz1q2mix.png",
		"images/compactmaps/overlays/openz1q1mixm.png",
		"images/compactmaps/overlays/openz1q2mixm.png"
	},
	
	[ "recorderoverlay" ] = {
		"images/compactmaps/overlays/recorderz1q1.png",
		"images/compactmaps/overlays/recorderz1q2.png",
		"images/compactmaps/overlays/recorderz1q1m.png",
		"images/compactmaps/overlays/recorderz1q2m.png",
		"images/compactmaps/overlays/recorderz1q1mix.png",
		"images/compactmaps/overlays/recorderz1q2mix.png",
		"images/compactmaps/overlays/recorderz1q1mixm.png",
		"images/compactmaps/overlays/recorderz1q2mixm.png"
	},
	
	[ "bomboverlay" ] = {
		"images/compactmaps/overlays/bombz1q1.png",
		"images/compactmaps/overlays/bombz1q2.png",
		"images/compactmaps/overlays/bombz1q1m.png",
		"images/compactmaps/overlays/bombz1q2m.png",
		"images/compactmaps/overlays/bombz1qmix.png",
		"images/compactmaps/overlays/bombz1qmix.png",
		"images/compactmaps/overlays/bombz1qmixm.png",
		"images/compactmaps/overlays/bombz1qmixm.png"
	},
	
	[ "candleoverlay" ] = {
		"images/compactmaps/overlays/candlez1q1.png",
		"images/compactmaps/overlays/candlez1q2.png",
		"images/compactmaps/overlays/candlez1q1m.png",
		"images/compactmaps/overlays/candlez1q2m.png",
		"images/compactmaps/overlays/candlez1qmix.png",
		"images/compactmaps/overlays/candlez1qmix.png",
		"images/compactmaps/overlays/candlez1qmixm.png",
		"images/compactmaps/overlays/candlez1qmixm.png"
	},
	
	[ "powerbraceletoverlay" ] = {
		"images/compactmaps/overlays/powerbraceletz1q1.png",
		"images/compactmaps/overlays/powerbraceletz1q2.png",
		"images/compactmaps/overlays/powerbraceletz1q1m.png",
		"images/compactmaps/overlays/powerbraceletz1q2m.png",
		"images/compactmaps/overlays/powerbraceletz1qmix.png",
		"images/compactmaps/overlays/powerbraceletz1qmix.png",
		"images/compactmaps/overlays/powerbraceletz1qmixm.png",
		"images/compactmaps/overlays/powerbraceletz1qmixm.png"
	}
}
-- Here we store references by code name so we can access our custom OverlayItems more easily
OverlayReference = {}

-- As with PaletteItems we avoid using setProperty here, in this case because the state of these is meant to be purely based on other item states
function OverlayItem:init(code,imageTable)
	self:createItem(code)
    self.code = code
    self.active = false
	self.imageTable = imageTable
    self.activeImage = ImageReference:FromPackRelativePath(self.imageTable[1])
    self.disabledImage = ImageReference:FromPackRelativePath("images/compactmaps/overlays/blank.png")
    self.ItemInstance.PotentialIcon = self.activeImage
	OverlayReference[code] = self

    self:updateIcon()
end

function OverlayItem:setStage(value)
	self.activeImage = ImageReference:FromPackRelativePath(self.imageTable[value])
	self:updateIcon()
end

function OverlayItem:updateIcon()
    if self.active then
        self.ItemInstance.Icon = self.activeImage
    else
        self.ItemInstance.Icon = self.disabledImage
    end
end

function OverlayItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function OverlayItem:providesCode(code)
    if code == self.code and self.active then
        return 1
    end
    return 0
end

-- The various states of OverlayItems are meant to be controlled exclusively through other items, so we don't save any data
function OverlayItem:save()
end

function UpdateOverlays()
	for overlay,requirement in pairs(OverlayCodes) do
		local target = OverlayReference[overlay]
		local item = Tracker:FindObjectForCode(requirement)
		if	(requirement == "candle") then
			if item.CurrentStage > 0 then
				target.active = true
			else
				target.active = false
			end
		else
			target.active = item.Active
		end
		target:setStage(StageForOverlays)
	end
end

for code,imageTable in pairs(OverlayData) do
	local newItem = OverlayItem(code,imageTable)
end

-- This is effectively three bits adding up to the current settings, which equate to the stage we want an overlay item set to
function CheckSettings()
	-- We start at 1 because arrays in lua do too
	StageForOverlays = 1
	if Tracker:FindObjectForCode("queststate").Active then
		StageForOverlays = StageForOverlays + 1
	end
	if Tracker:FindObjectForCode("mirrored").Active then
		StageForOverlays = StageForOverlays + 2
	end
	if Tracker:FindObjectForCode("mixedquest").Active then
		StageForOverlays = StageForOverlays + 4
	end
end

function tracker_on_accessibility_updated()
	CheckSettings()
	UpdateOverlays()
end