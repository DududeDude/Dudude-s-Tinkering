-- This script fully defines all items used by the dungeon map
-- It does so through creating 176 different items for the map itself, as well as the appropriate items for the selection and palette
-- These 176 items then each store 9 different stages, with the one being modified and displayed being defined by what level is selected
-- This could have been done more conventionally by increasing the amount of items defined, but I wanted the extra customizability on placing the level selection

-- Just basic item definitions, mostly built this way to be more explicit and allow easier referencing
local DungeonSelectorData = {
	{
		["name"] = "Level 1",
		["code"] = "selectorlevel1",
		["image"] = "images/compactlocations/levelone.png",
	},

	{
		["name"] = "Level 2",
		["code"] = "selectorlevel2",
		["image"] = "images/compactlocations/leveltwo.png",
	},	
	
	{
		["name"] = "Level 3",
		["code"] = "selectorlevel3",
		["image"] = "images/compactlocations/levelthree.png",
	},
	
	{
		["name"] = "Level 4",
		["code"] = "selectorlevel4",
		["image"] = "images/compactlocations/levelfour.png",
	},
	
	{
		["name"] = "Level 5",
		["code"] = "selectorlevel5",
		["image"] = "images/compactlocations/levelfive.png",
	},
	
	{
		["name"] = "Level 6",
		["code"] = "selectorlevel6",
		["image"] = "images/compactlocations/levelsix.png",
	},
	
	{
		["name"] = "Level 7",
		["code"] = "selectorlevel7",
		["image"] = "images/compactlocations/levelseven.png",
	},
	
	{
		["name"] = "Level 8",
		["code"] = "selectorlevel8",
		["image"] = "images/compactlocations/leveleight.png",
	},
	
	{
		["name"] = "Level 9",
		["code"] = "selectorlevel9",
		["image"] = "images/compactlocations/levelnine.png",
	}
}

-- These are the vanilla dungeon maps, to apply to different level maps when right-clicked
local DungeonPatterns = {
	-- Level 1
	{
		{
			0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 1, 1, 0, 0, 0, 0,
			0, 0, 0, 1, 0, 1, 1, 0,
			0, 1, 1, 1, 1, 1, 0, 0,
			0, 0, 1, 1, 1, 0, 0, 0,
			0, 0, 0, 1, 0, 0, 0, 0,
			0, 0, 1, 1, 1, 0, 0, 0
		},
		{
			0, 0, 0, 1, 1, 0, 0, 0,
			0, 0, 0, 1, 1, 0, 0, 0,
			0, 0, 0, 1, 0, 0, 0, 0,
			0, 0, 0, 1, 1, 0, 0, 0,
			0, 0, 0, 1, 1, 0, 0, 0,
			0, 0, 0, 1, 0, 0, 0, 0,
			0, 0, 0, 1, 1, 0, 0, 0,
			0, 0, 0, 1, 1, 0, 0, 0
		}
	},

	-- Level 2
	{
		{
			0, 0, 0, 1, 1, 0, 0, 0,
			0, 0, 0, 0, 1, 1, 0, 0,
			0, 0, 0, 0, 1, 1, 0, 0,
			0, 0, 0, 0, 1, 1, 0, 0,
			0, 0, 0, 0, 1, 1, 0, 0,
			0, 0, 0, 0, 1, 1, 0, 0,
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 0, 0, 1, 1, 0, 0, 0
		},
		{
			0, 0, 0, 1, 0, 0, 0, 0,
			0, 0, 1, 1, 1, 0, 0, 0,
			0, 0, 1, 1, 1, 0, 0, 0,
			0, 0, 1, 1, 1, 0, 0, 0,
			0, 0, 1, 1, 1, 0, 0, 0,
			0, 0, 1, 1, 1, 0, 0, 0,
			0, 0, 1, 0, 1, 0, 0, 0,
			0, 0, 1, 0, 1, 0, 0, 0
		}
	},

	-- Level 3
	{
		{
			0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 1, 1, 0, 0, 0, 0,
			0, 0, 0, 1, 0, 1, 0, 0,
			0, 1, 1, 1, 1, 1, 0, 0,
			0, 1, 1, 1, 1, 1, 0, 0,
			0, 1, 0, 1, 0, 0, 0, 0,
			0, 0, 0, 1, 1, 0, 0, 0
		},
		{
			0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 1, 0, 0,
			1, 0, 0, 0, 0, 1, 0, 0,
			1, 0, 0, 0, 0, 1, 0, 0,
			0, 0, 0, 0, 0, 1, 0, 0,
			0, 0, 0, 0, 0, 1, 0, 0,
			0, 0, 0, 0, 0, 1, 1, 0,
			0, 0, 0, 0, 0, 1, 1, 0
		}
	},

	-- Level 4
	{
		{
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 0, 1, 1, 0, 0, 0, 0,
			0, 0, 1, 1, 1, 0, 0, 0,
			0, 0, 1, 0, 0, 0, 0, 0,
			0, 0, 1, 1, 0, 0, 0, 0,
			0, 0, 0, 1, 1, 0, 0, 0,
			0, 0, 1, 1, 0, 0, 0, 0
		},
		{
			0, 0, 1, 1, 1, 0, 0, 0,
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 0, 1, 1, 1, 0, 0, 0
		}
	},
	
	-- Level 5
	{
		{
			0, 0, 0, 1, 1, 0, 0, 0,
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 0, 1, 0, 0, 1, 0, 0,
			0, 0, 0, 0, 1, 1, 0, 0,
			0, 0, 0, 1, 1, 1, 0, 0,
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 0, 0, 0, 1, 1, 0, 0
		},
		{
			0, 0, 1, 1, 1, 0, 0, 0,
			0, 0, 1, 1, 1, 0, 0, 0,
			0, 0, 0, 0, 1, 0, 0, 0,
			0, 0, 0, 1, 1, 0, 0, 0,
			0, 0, 1, 1, 0, 0, 0, 0,
			0, 0, 1, 0, 0, 0, 0, 0,
			0, 0, 1, 1, 1, 0, 0, 0,
			0, 0, 1, 1, 1, 0, 0, 0
		}
	},

	-- Level 6
	{
		{
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 1, 1, 1, 1, 1, 1, 0,
			0, 1, 1, 0, 0, 1, 1, 0,
			0, 1, 1, 1, 0, 1, 0, 0,
			0, 1, 0, 0, 0, 0, 0, 0,
			0, 1, 0, 0, 0, 0, 0, 0,
			0, 1, 0, 1, 0, 0, 0, 0,
			0, 1, 1, 1, 0, 0, 0, 0
		},
		{
			0, 0, 0, 0, 1, 1, 1, 0,
			0, 0, 0, 1, 1, 0, 1, 0,
			0, 0, 0, 1, 1, 0, 1, 0,
			0, 0, 0, 1, 1, 0, 1, 0,
			0, 0, 1, 1, 1, 0, 0, 0,
			0, 1, 1, 1, 1, 0, 0, 0,
			0, 0, 0, 1, 1, 0, 0, 0,
			0, 0, 0, 0, 1, 0, 0, 0
		}
	},

	-- Level 7
	{
		{
			0, 1, 1, 1, 1, 1, 1, 0,
			0, 1, 1, 1, 1, 1, 0, 0,
			0, 1, 1, 1, 1, 0, 0, 0,
			0, 1, 1, 1, 0, 0, 0, 0,
			0, 1, 1, 0, 0, 0, 0, 0,
			0, 1, 1, 1, 1, 0, 0, 0,
			0, 1, 1, 1, 1, 1, 1, 0,
			0, 1, 1, 1, 0, 0, 0, 0
		},
		{
			0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 1, 1, 1, 1, 1, 0,
			0, 0, 1, 0, 0, 0, 1, 0,
			0, 0, 1, 1, 1, 0, 1, 0,
			0, 0, 1, 1, 1, 0, 1, 0,
			0, 0, 1, 1, 1, 0, 1, 0,
			0, 0, 0, 0, 0, 0, 1, 0,
			1, 1, 1, 1, 1, 1, 1, 0
		}
	},
	
	-- Level 8
	{
		{
			0, 0, 0, 0, 1, 0, 0, 0,
			0, 0, 0, 1, 1, 1, 0, 0,
			0, 0, 1, 1, 1, 0, 0, 0,
			0, 1, 1, 1, 1, 1, 0, 0,
			0, 1, 1, 1, 1, 0, 0, 0,
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 0, 0, 0, 1, 0, 0, 0,
			0, 0, 1, 1, 1, 1, 0, 0
		},
		{
			1, 1, 1, 1, 1, 1, 1, 1,
			1, 1, 0, 0, 0, 0, 0, 1,
			1, 1, 0, 0, 0, 1, 0, 1,
			1, 1, 0, 0, 0, 1, 0, 1,
			1, 1, 0, 0, 0, 1, 0, 1,
			1, 1, 0, 0, 0, 1, 0, 1,
			1, 1, 1, 1, 1, 1, 0, 1,
			0, 0, 0, 0, 0, 0, 0, 1
		}
	},

	-- Level 9
	{
		{
			0, 1, 1, 1, 1, 1, 1, 1,
			1, 1, 1, 1, 1, 1, 1, 1,
			1, 1, 1, 1, 1, 1, 1, 1,
			1, 1, 1, 1, 1, 1, 1, 1,
			1, 1, 1, 1, 1, 1, 1, 1,
			1, 1, 1, 1, 1, 1, 1, 1,
			0, 1, 1, 1, 1, 1, 1, 0,
			0, 1, 0, 1, 1, 0, 1, 0
		},
		{
			1, 1, 0, 0, 0, 0, 1, 1,
			1, 1, 1, 1, 1, 1, 1, 1,
			0, 0, 1, 1, 1, 1, 0, 0,
			0, 1, 1, 1, 1, 1, 1, 0,
			1, 1, 1, 1, 1, 1, 1, 1,
			1, 1, 1, 1, 1, 1, 1, 1,
			0, 1, 1, 1, 1, 1, 1, 0,
			0, 0, 0, 1, 1, 0, 0, 0
		}
	}
}

-- Here we store all generated non-selector items
local DungeonItemCache = {}

-- This function gets called when the selected level changes, it then iterates through the cache and calls the function each individual item has to update its image to the selected level
function ChangeDisplayedLevel()
	for i,item in pairs(DungeonItemCache) do
		item:AssignImage()
	end
end

-- This stores the currently selected level
local CurrentSelector

-- Dungeon Selectors are mutually exclusive toggles of which one is always enabled
-- They control which level is currently displayed and being edited
DungeonSelectorItem = class(CustomItem)


function DungeonSelectorItem:init(name,code,image,index)
	self:createItem(name)
	self.code = code
	-- This is to set up the default state, where level 1 is active
	-- We also avoid using setProperty here since we don't want these affected by undo
	if (index == 1) then
		self.active = true
		CurrentSelector = self
	else
		self.active = false
	end
	self.index = index
	self.activeImage = ImageReference:FromPackRelativePath(image)
	self.disabledImage = ImageReference:FromImageReference(self.activeImage, "@disabled")
	self.patternLevel = 0
	self.patternQuest = 0
	
	self:updateIcon()
end

function DungeonSelectorItem:updateIcon()
	if self.active then
		self.ItemInstance.Icon = self.activeImage
	else
		self.ItemInstance.Icon = self.disabledImage
	end
end

function DungeonSelectorItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function DungeonSelectorItem:providesCode(code)
    if code == self.code and self.active then
        return 1
    end
    return 0
end

-- Left clicking explicitly checks if the item is already active, before disabling the current selector and turning itself into the new one
-- This is technically not required, but since each left click on these causes a lot of background interactions to happen, it's much cleaner this way
function DungeonSelectorItem:onLeftClick()
	if not self.active then
		CurrentSelector.active = false
		CurrentSelector:updateIcon()
		CurrentSelector = self
		self.active = true
		ChangeDisplayedLevel()
		self:updateIcon()
	end
end

-- This switches between the different dungeon patterns; aka the vanilla dungeon maps
-- We also check if the quest is set to something higher than 2 to reset to a base state
function DungeonSelectorItem:onRightClick()
	if CurrentSelector.patternLevel ~= self.index then
		CurrentSelector.patternLevel = self.index
		CurrentSelector.patternQuest = 1
	else
		CurrentSelector.patternQuest = CurrentSelector.patternQuest + 1
		if CurrentSelector.patternQuest > 2 then
			CurrentSelector.patternLevel = 0
			CurrentSelector.patternQuest = 0
		end
	end
	ChangeDisplayedLevel()
end

-- We do save data on which level is active, if someone had to take a break it's fairly likely they'll be back to the last dungeon they were editing next time they play
function DungeonSelectorItem:save()
	local saveData = {
		["active"] = self.active,
		["patternLevel"] = self.patternLevel,
		["patternQuest"] = self.patternQuest
	}
	return saveData
end

-- Loading is a bit more complicated than usual, since we have to disable the already initialized base state as part of it, with an exception coded in if it's level 1
-- Since we're defining these items first though we don't have to fire the ChangeDisplayedLevel function, EmoTracker will load the items affected after this selector has been
function DungeonSelectorItem:load(data)
	if data ~= nil then
		self.active = data["active"]
		self.patternLevel = data["patternLevel"]
		self.patternQuest = data["patternQuest"]
		if self.active and self.index ~= 1 then
			CurrentSelector.active = false
			CurrentSelector:updateIcon()
			CurrentSelector = self
			self:updateIcon()
		end
	end
	return true
end

for i,data in pairs(DungeonSelectorData) do
	local newItem = DungeonSelectorItem(data["name"], data["code"], data["image"], i)
end


-- Data for the dungeon palette is somewhat differently formatted than it is with the compact map
-- Particularly we define the right click item within this as well, and the image definition is a table, where 0 is the default choice, and other numbers will use that image for that specific level
-- Currently this is only used to change the bomb upgrade into Ganon and the triforce into Zelda, but I could support custom colored tiles for every individual dungeon
local DungeonPaletteData = {

	-- Default
	[0] = {
		["name"] = "Blank",
		["code"] = "dungeonblank",
		["image"] = {
			[0] = "images/dungeonmaps/blank.png"
		}
	},
	
	-- Stairs
	{
		["name"] = "Stairs 1",
		["code"] = "dungeonstairs1",
		["image"] = {
			[0] = "images/dungeonmaps/stairs1.png"
		}
	},
	
	{
		["name"] = "Stairs 2",
		["code"] = "dungeonstairs2",
		["image"] = {
			[0] = "images/dungeonmaps/stairs2.png"
		}
	},
	
	{
		["name"] = "Stairs 3",
		["code"] = "dungeonstairs3",
		["image"] = {
			[0] = "images/dungeonmaps/stairs3.png"
		}
	},
	
	{
		["name"] = "Stairs 4",
		["code"] = "dungeonstairs4",
		["image"] = {
			[0] = "images/dungeonmaps/stairs4.png"
		}
	},
	
	{
		["name"] = "Stairs 5",
		["code"] = "dungeonstairs5",
		["image"] = {
			[0] = "images/dungeonmaps/stairs5.png"
		}
	},
	
	{
		["name"] = "Stairs 6",
		["code"] = "dungeonstairs6",
		["image"] = {
			[0] = "images/dungeonmaps/stairs6.png"
		}
	},
	
	{
		["name"] = "Stairs 7",
		["code"] = "dungeonstairs7",
		["image"] = {
			[0] = "images/dungeonmaps/stairs7.png"
		}
	},
	
	{
		["name"] = "Stairs 8",
		["code"] = "dungeonstairs8",
		["image"] = {
			[0] = "images/dungeonmaps/stairs8.png"
		}
	},
	
	{
		["name"] = "Stairs 9",
		["code"] = "dungeonstairs9",
		["image"] = {
			[0] = "images/dungeonmaps/stairs9.png"
		}
	},
	
	{
		["name"] = "Stairs Unknown",
		["code"] = "dungeonstairsunknown",
		["image"] = {
			[0] = "images/dungeonmaps/stairsunknown.png"
		}
	},
	
	-- Ladder Blocks
	
	{
		["name"] = "Horizontal Moat",
		["code"] = "dungeonhmoat",
		["image"] = {
			[0] = "images/dungeonmaps/horizontalmoat.png"
		}
	},
	
	{
		["name"] = "Vertical Moat",
		["code"] = "dungeonvmoat",
		["image"] = {
			[0] = "images/dungeonmaps/verticalmoat.png"
		}
	},
	
	{
		["name"] = "Double Moat",
		["code"] = "dungeondmoat",
		["image"] = {
			[0] = "images/dungeonmaps/doublemoat.png"
		}
	},
	
	{
		["name"] = "T Room",
		["code"] = "dungeontroom",
		["image"] = {
			[0] = "images/dungeonmaps/t.png"
		}
	},
	
	{
		["name"] = "N Room",
		["code"] = "dungeonnroom",
		["image"] = {
			[0] = "images/dungeonmaps/n.png"
		}
	},
	
	{
		["name"] = "Chevy Room",
		["code"] = "dungeonchevy",
		["image"] = {
			[0] = "images/dungeonmaps/chevy.png"
		}
	},
	
	-- Chutes
	
	{
		["name"] = "Horizontal Chute",
		["code"] = "dungeonhchute",
		["image"] = {
			[0] = "images/dungeonmaps/horizontalchute.png"
		}
	},
	
	{
		["name"] = "Vertical Chute",
		["code"] = "dungeonvchute",
		["image"] = {
			[0] = "images/dungeonmaps/verticalchute.png"
		}
	},
	
	-- Everything else
	
	{
		["name"] = "Digdogger",
		["code"] = "dungeondigdogger",
		["image"] = {
			[0] = "images/dungeonmaps/digdogger.png"
		}
	},
	
	{
		["name"] = "Gohma",
		["code"] = "dungeongohma",
		["image"] = {
			[0] = "images/dungeonmaps/gohma.png"
		}
	},
	
	{
		["name"] = "Bait Block",
		["code"] = "dungeonbaitblock",
		["image"] = {
			[0] = "images/dungeonmaps/baitblock.png"
		}
	},
	
	{
		["name"] = "Bomb Upgrade / Ganon",
		["code"] = "dungeonganon",
		["image"] = {
			[0] = "images/dungeonmaps/bombupgrade.png",
			[9] = "images/dungeonmaps/ganon.png"
		}
	},
	
	{
		["name"] = "Extortion",
		["code"] = "dungeonmoneyorlife",
		["image"] = {
			[0] = "images/dungeonmaps/moneyorlife.png"
		}
	},
	
	{
		["name"] = "Triforce / Zelda",
		["code"] = "dungeonzelda",
		["image"] = {
			[0] = "images/dungeonmaps/triforce.png",
			[9] = "images/dungeonmaps/zelda.png"
		}
	},
	
	{
		["name"] = "Entrance",
		["code"] = "dungeonentrance",
		["image"] = {
			[0] = "images/dungeonmaps/entrance.png"
		}
	},
	
	{
		["name"] = "Item",
		["code"] = "dungeonitem",
		["image"] = {
			[0] = "images/dungeonmaps/item.png"
		}
	}
}

-- These are all commonly referenced items, three are effectively fixed, DungeonPalette changes based on whichever one is currently selected
local DungeonBlank
local DungeonPalette
local DungeonRightClick = "overlay|images/dungeonmaps/nothing.png"
local DungeonEmpty = "@disabled"

-- The Dungeon Palette Items are mutually exclusive items, only one will ever be active at the same time
-- They control what graphic to add to a map square on left click
DungeonPaletteItem = class(CustomItem)

function DungeonPaletteItem:init(name,code,image,index)
	self:createItem(name)
	self.code = code
	self.active = false
	self.images = {}
	-- This is mostly so we only have to convert the images to references once
	for i,ref in pairs(image) do
		self.images[i] = ImageReference:FromPackRelativePath(ref)
	end
	self:AssignImage()
	self.ItemInstance.PotentialIcon = self.activeImage
	self.index = index
	
	-- Here we set the default palette entry (which is just the blank), and store our commonly referenced palette items
	if index == 0 then
		DungeonBlank = self
		DungeonPalette = self
	-- We don't bother caching the blank and right click items, those aren't normally visible so they'll never have to be updated
	else
		DungeonItemCache[self.code] = self
	end
end

-- The AssignImage function here checks if a specific image for the current level exists, and sets to the default if it doesn't
function DungeonPaletteItem:AssignImage()
	if self.images[CurrentSelector.index] then
		self.activeImage = self.images[CurrentSelector.index]
	else
		self.activeImage = self.images[0]
	end
	self.disabledImage = ImageReference:FromImageReference(self.activeImage, "@disabled")
	self:UpdateIcon()
end

function DungeonPaletteItem:UpdateIcon()
	if self.active then
		self.ItemInstance.Icon = self.activeImage
	else
		self.ItemInstance.Icon = self.disabledImage
	end
end

function DungeonPaletteItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function DungeonPaletteItem:providesCode(code)
    if code == self.code and self.active then
        return 1
    end
    return 0
end

-- Again checking if the item isn't active is not technically required, but it's neater
function DungeonPaletteItem:onLeftClick()
	if not self.active then
		DungeonPalette.active = false
		DungeonPalette:UpdateIcon()
		DungeonPalette = self
		self.active = true
		self:UpdateIcon()
	end
end

-- Though double checking that the item is active on right click is very important
function DungeonPaletteItem:onRightClick()
	if self.active then
		DungeonPalette = DungeonBlank
		self.active = false
		self:UpdateIcon()
	end
end

-- The save function is blanked out here since I don't want to save the currently selected palette
function DungeonPaletteItem:save()
end

for i,data in pairs(DungeonPaletteData) do
	local newItem = DungeonPaletteItem(data["name"], data["code"], data["image"], i)
end

-- I actually define the map size this way in case I ever re-use this script for a different game with different map sizes
-- Mostly to help with the connections between rooms, since those use slightly less items than the full map
local DungeonMapWidth = 8
local DungeonMapHeight = 8

DungeonMapItem = class(CustomItem)

function DungeonMapItem:init(iteration)
	self:createItem("Dungeon Map")
	self.code = "dungeonmap" .. iteration
	-- This function pre-initializes the different properties based on the amount of levels we have defined as existing
	-- For Zelda 1 this ends up creating 9 different properties
	-- We use the codes of the different selectors as our naming here; this creates a nice unique set
	for i,data in pairs(DungeonSelectorData) do 
		self:setProperty(data["code"],DungeonBlank.index)
		self:setProperty(data["code"] .. "active",0)
	end
	self:AssignImage()
	self.iteration = iteration
	self.ItemInstance.PotentialIcon = self.assignedImage
	
	DungeonItemCache[self.code] = self
end

function DungeonMapItem:AssignImage()
	self.assignedImage = self:getImage()
	self:UpdateIcon()
end

function DungeonMapItem:getImage()
	local returnimage
	-- This looks intimidating but is fairly simple in practice, palette data is effectively laid out in this order:
	-- 1. ID number of the selected palette
	-- 2. Strings defining the different parts of that item; we just care about the image here
	-- 3. Unique graphics for different levels
	-- This function checks if a specific image for the current level exists, and goes to default if it doesn't
	if DungeonPaletteData[self:getIndex()]["image"][CurrentSelector.index] then
		returnimage = DungeonPaletteData[self:getIndex()]["image"][CurrentSelector.index]
	else
		returnimage = DungeonPaletteData[self:getIndex()]["image"][0]
	end
	return ImageReference:FromPackRelativePath(returnimage)
end

function DungeonMapItem:getIndex()
	return self:getProperty(CurrentSelector.code)
end

function DungeonMapItem:getActive()
	return self:getProperty(CurrentSelector.code .. "active")
end

function DungeonMapItem:UpdateIcon()
	if CurrentSelector.patternLevel > 0 then
		local temp = DungeonPatterns[CurrentSelector.patternLevel][CurrentSelector.patternQuest][self.iteration]
		if temp == 0 then
			self.assignedImage = ImageReference:FromImageReference(self.assignedImage, "@disabled")
		end
	end
	if self:getActive() == 1 then
		self.assignedImage = ImageReference:FromImageReference(self.assignedImage, DungeonRightClick)
	elseif self:getActive() == 2 then
		self.assignedImage = ImageReference:FromImageReference(self.assignedImage, DungeonEmpty)
	end
	self.ItemInstance.Icon = self.assignedImage
end

function DungeonMapItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function DungeonMapItem:providesCode(code)
    if code == self.code then
        return 1
    end
    return 0
end

function DungeonMapItem:onLeftClick()
	if self:getIndex() == DungeonPalette.index then
		self:setProperty(CurrentSelector.code, DungeonBlank.index)
	else
		self:setProperty(CurrentSelector.code, DungeonPalette.index)
	end
end

function DungeonMapItem:onRightClick()
	local temp = self:getActive()
	temp = temp + 1
	if temp > 2 then
		temp = 0
	end
	self:setProperty(CurrentSelector.code .. "active", temp)
end

function DungeonMapItem:propertyChanged(key, value)
	self:AssignImage()
end

function DungeonMapItem:save()
	local saveData = {}
	-- Saving once again iterates through the different potential properties, similar to how we originally defined them
	for i,data in pairs(DungeonSelectorData) do
		local temp = data["code"]
		saveData[temp] = self:getProperty(temp)
		saveData[temp .. "active"] = self:getProperty(temp .. "active")
	end
	return saveData
end

function DungeonMapItem:load(data)
	if data ~= nil then
		-- And loading is effectively the inverse of what we do when saving
		for i,info in pairs(DungeonSelectorData) do
			local temp = info["code"]
			self:setProperty(temp, data[temp])
			self:setProperty(temp .. "active", data[temp .. "active"])
		end
	end
	return true
end

for i=1,DungeonMapWidth * DungeonMapHeight do
	local newItem = DungeonMapItem(i)
end

-- Connectors are a bit simpler and are always going to look the same for each dungeon
-- The only thing that's different about them is that the direction they're oriented affects the image used
local DungeonConnectorData = {
	{
		["horizontal"] = "images/dungeonconnections/unknown.png",
		["vertical"] = "images/dungeonconnections/unknown.png"
	},
	
	{
		["horizontal"] = "images/dungeonconnections/horizontal.png",
		["vertical"] = "images/dungeonconnections/vertical.png"
	},
	
	{
		["horizontal"] = "images/dungeonconnections/horizontalarrow1.png",
		["vertical"] = "images/dungeonconnections/verticalarrow2.png"
	},
	
	{
		["horizontal"] = "images/dungeonconnections/horizontalarrow2.png",
		["vertical"] = "images/dungeonconnections/verticalarrow1.png"
	},
	
	{
		["horizontal"] = "images/dungeonconnections/horizontalshutter.png",
		["vertical"] = "images/dungeonconnections/verticalshutter.png"
	},
	
	{
		["horizontal"] = "images/dungeonconnections/locked.png",
		["vertical"] = "images/dungeonconnections/locked.png"
	},
	
	{
		["horizontal"] = "images/dungeonconnections/nothing.png",
		["vertical"] = "images/dungeonconnections/nothing.png"
	},
}

-- While I could have figured out the amount of stages by iterating through the array above, I just opted for hard defining it instead
local DungeonConnectorStages = 7

DungeonConnectorItem = class(CustomItem)

-- We need to supply both the iteration and orientation for these to properly define them
function DungeonConnectorItem:init(iteration,orientation)
	self:createItem("Connector")
	self.code = "dungeonconnector" .. orientation .. iteration
	for i,data in pairs(DungeonSelectorData) do 
		self:setProperty(data["code"],1)
	end
	self.images = {}
	-- This loop stores the images to be used by this particular item
	for i,data in pairs(DungeonConnectorData) do
		self.images[i] = ImageReference:FromPackRelativePath(data[orientation])
	end
	self:AssignImage()

	DungeonItemCache[self.code] = self
end

function DungeonConnectorItem:getStage()
	return self:getProperty(CurrentSelector.code)
end

function DungeonConnectorItem:AssignImage()
	if self.images then
		self.assignedImage = self.images[self:getStage()]
		self:updateIcon()
	end
end

function DungeonConnectorItem:updateIcon()
	self.ItemInstance.Icon = self.assignedImage
end

function DungeonConnectorItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function DungeonConnectorItem:providesCode(code)
    if code == self.code then
        return 1
    end
    return 0
end

-- These items effectively act as regular looping progressives
-- They still have to specially defined because unlike regular ones they need to store separate values for all 9 different levels
-- And I didn't really want to define the amount of items required manually
function DungeonConnectorItem:onLeftClick()
	local NewValue = self:getStage() + 1
	if NewValue > DungeonConnectorStages then
		NewValue = 1
	end
	self:setProperty(CurrentSelector.code,NewValue)
end

function DungeonConnectorItem:onRightClick()
	local NewValue = self:getStage() - 1
	if NewValue < 1 then
		NewValue = DungeonConnectorStages
	end
	self:setProperty(CurrentSelector.code,NewValue)
end

function DungeonConnectorItem:propertyChanged(key,value)
	self:AssignImage()
end

-- Saving and loading here basically work the exact way as they do for the map squares
function DungeonConnectorItem:save()
	local saveData = {}
	for i,data in pairs(DungeonSelectorData) do
		saveData[data["code"]] = self:getProperty(data["code"])
	end
	return saveData
end

function DungeonConnectorItem:load(data)
	if data ~= nil then
		for i,info in pairs(DungeonSelectorData) do
			self:setProperty(info["code"], data[info["code"]])
		end
	end
	return true
end

for i=1, (DungeonMapWidth - 1) * DungeonMapHeight do
	local newItem = DungeonConnectorItem(i,"horizontal")
end

for i=1, DungeonMapWidth * (DungeonMapHeight - 1) do
	local newItem = DungeonConnectorItem(i,"vertical")
end

-- Need this in here so it properly loads the map pattern
function tracker_on_finish_loading_save_file()
	ChangeDisplayedLevel()
end