CaptureBadgeSections = {
	-- Death Mountain
	"@A1 - Second Quest Level 9/Bomb Wall",
	"@B1 - Bomb Wall/Bomb Wall",
	"@C1 - Bomb Wall/Bomb Wall",
	"@D1 - Bomb Wall/Bomb Wall",
	"@E1 - Open Cave/Open Cave",
	"@F1 - Spectacle Rock/Bomb Wall",
	"@G1 - Recorder Spot/Use Recorder",
	"@H1 - Bomb Wall/Bomb Wall",
	"@J1 - Arrow/Push Rock",
	"@A2 - Bomb Wall/Bomb Wall",
	"@B2 - Second Quest Letter/Push Rock",
	"@C2 - Bomb Wall/Bomb Wall",
	"@D2 - Bomb Wall/Bomb Wall",
	"@E2 - Bomb Wall/Bomb Wall",
	"@F2 - Bomb Wall/Bomb Wall",
	"@G2 - Bomb Wall/Bomb Wall",
	
	-- Graveyard
	"@A3 - Push Grave/Push Grave",
	"@B3 - First Quest Magic Sword/Push Grave",
	"@C3 - First Quest Level 6/Open Cave",
	"@D3 - Graveyard Warp/Push Rock",
	"@E3 - Graveyard Armos/Under Armos",
	"@F3 - Graveyard Shop/Open Cave",
	"@A4 - Recorder Spot/Use Recorder",
	"@D4 - Bomb Wall/Bomb Wall",
	"@A7 - Recorder Spot/Use Recorder",
	
	-- Dead Woods
	"@B6 - Burn Bush/Burn Bush",
	"@D6 - Burn Bush/Burn Bush",
	"@C7 - Burn Bush/Burn Bush",
	"@D7 - Burn Bush/Burn Bush",
	"@A8 - Vanilla Hint Shop/Open Cave",
	"@B8 - Bomb Wall/Bomb Wall",
	"@C8 - Recorder Spot/Use Recorder",
	"@E7 - Dead Woods Shop/Open Cave",
	"@E8 - First Quest Level 3/Open Cave",
	
	-- Lake
	"@K1 - First Quest White Sword/Open Cave",
	"@G3 - Forgotten Spot/Bomb Wall",
	"@E4 - Lake Armos/Under Armos",
	"@H4 - Vanilla Level 1/Open Cave",
	"@C5 - First Quest Level 7/Use Recorder",
	"@E5 - Lake Shop/Open Cave",
	"@F5 - First Quest Level 4/Raft from F6",
	"@G5 - Burn Bush/Burn Bush",
	"@H5 - Burn Bush/Burn Bush",
	"@I5 - Burn Bush/Burn Bush",
	"@G6 - Burn Bush/Burn Bush",
	"@K7 - Burn Bush/Burn Bush",
	
	-- River
	"@I2 - Bomb Wall/Bomb Wall Behind River",
	"@J2 - Bomb Wall/Bomb Wall Behind River",
	"@K2 - Waterfall/Enter Waterfall",
	"@H3 - Bomb Wall/Bomb Wall",
	"@F8 - Open Cave/Open Cave",
	
	-- Start
	"@I6 - Recorder Spot/Use Recorder",
	"@G7 - Start Shop/Open Cave",
	"@H7 - Bomb Wall/Bomb Wall",
	"@I7 - Burn Bush/Burn Bush",
	"@G8 - Bomb Wall/Bomb Wall",
	"@H8 - First Quest Wood Sword/Open Cave",
	"@I8 - Burn Bush/Burn Bush",
	"@J8 - Start Warp/Push Rock",
	
	-- Desert
	"@I3 - Burn Bush/Burn Bush",
	"@J3 - Recorder Spot/Use Recorder",
	"@L3 - Recorder Spot/Use Recorder",
	"@M3 - Monocle Rock/Bomb Wall",
	"@K4 - Recorder Spot/Use Recorder",
	"@J5 - Desert Warp/Push Rock",
	"@K5 - Desert Shop/Open Cave",
	"@L5 - Burn Bush/Burn Bush",
	
	-- Lost Hills
	"@L1 - First Quest Level 5/Open Cave",
	"@M1 - Lost Hills Shop/Open Cave",
	"@N1 - Bomb Wall/Bomb Wall",
	"@L2 - Push Rock/Push Rock",
	"@M2 - Lost Hills Armos/Under Armos",
	"@N2 - Lost Hills Warp/Push Rock",
	
	-- Forest
	"@M4 - First Quest Level 2/Open Cave",
	"@M4 - Second Quest Level 3/Use Recorder",
	"@N4 - Upper Forest Armos/Under Armos",
	"@N5 - Burn Bush/Burn Bush",
	"@O5 - Lower Forest Armos/Under Armos",
	"@L6 - Burn Bush/Burn Bush",
	"@O6 - Forest Shop/Open Cave",
	"@L7 - Burn Bush/Burn Bush",
	"@M7 - Burn Bush/Burn Bush",
	"@N7 - First Quest Level 8/Burn Bush",
	"@O7 - Recorder Spot/Use Recorder",
	
	-- Coast
	"@O1 - First Quest Letter/Open Cave",
	"@P1 - Corner Secret/Walk Through P2 Wall",
	"@O2 - Bomb Wall/Bomb Wall",
	"@P2 - Coast Gambling/Open Cave",
	"@N3 - Bomb Wall/Bomb Wall",
	"@P3 - Raft Spot/Raft from P4",
	"@P6 - Overworld Item/Use Ladder",
	"@P7 - Coast Shop/Open Cave",
	"@L8 - Bomb Wall/Bomb Wall",
	"@M8 - Bomb Wall/Bomb Wall",
	"@N8 - Bomb Wall/Bomb Wall"
}

CaptureBadgeCache = {}

function tracker_on_accessibility_updated()
	for i,section in pairs(CaptureBadgeSections) do
		local target = Tracker:FindObjectForCode(section)
		-- Has the captured item for this section changed since last update
		if not target then
			print("Failed to resolve " .. section)
		elseif target.CapturedItem ~= CaptureBadgeCache[target] then
			-- Does the location that owns this section already have a badge, if so remove it
			if CaptureBadgeCache[target.Owner] then
				target.Owner:RemoveBadge(CaptureBadgeCache[target.Owner])
				CaptureBadgeCache[target.Owner] = nil
				CaptureBadgeCache[target] = nil
			end
			-- Check if a captured item exists, add as badge to the sections owner if it does
			if target.CapturedItem then
				CaptureBadgeCache[target.Owner] = target.Owner:AddBadge(target.CapturedItem.PotentialIcon)
				CaptureBadgeCache[target] = target.CapturedItem
			end
		end
	end
end