-- The image to set to on right click, for this pack it's the x on a gray background
local OnRightClickGridImage = "overlay|images/dungeongrid/checkmark.png"

-- The amount of separate compact map squares to create, will be created as dungeongrid(one through set count)
local DungeonGridLocationCount = 21

local DungeonGridData = {
	-- Level 1
	{
		["name"] = "Heart Floor Drop",
		["image"] = "images/dungeongrid/dungeonfloorheart.png",
	},
	
	{
		["name"] = "Floor Drop",
		["image"] = "images/dungeongrid/dungeonfloor.png",
	},
	
	{
		["name"] = "Stairs Item (1Q)",
		["image"] = "images/dungeongrid/dungeonstairsq1.png",
	},
	
	-- Level 2
	{
		["name"] = "Heart Floor Drop",
		["image"] = "images/dungeongrid/dungeonfloorheart.png",
	},
	
	{
		["name"] = "Floor Drop (1Q), Stairs Item (2Q)",
		["image"] = "images/dungeongrid/dungeonfloorstairs.png",
	},
	
	-- Level 3
	{
		["name"] = "Heart Floor Drop",
		["image"] = "images/dungeongrid/dungeonfloorheart.png",
	},
	
	{
		["name"] = "Stairs Item (1Q), Floor Drop (2Q)",
		["image"] = "images/dungeongrid/dungeonstairsfloor.png",
	},
	
	-- Level 4
	{
		["name"] = "Heart Floor Drop",
		["image"] = "images/dungeongrid/dungeonfloorheart.png",
	},
	
	{
		["name"] = "Stairs Item",
		["image"] = "images/dungeongrid/dungeonstairs.png",
	},
	
	{
		["name"] = "Stairs Item (2Q)",
		["image"] = "images/dungeongrid/dungeonstairsq2.png",
	},
	
	-- Level 5
	{
		["name"] = "Heart Floor Drop",
		["image"] = "images/dungeongrid/dungeonfloorheart.png",
	},
	
	{
		["name"] = "Stairs Item",
		["image"] = "images/dungeongrid/dungeonstairs.png",
	},
	
	-- Level 6
	{
		["name"] = "Heart Floor Drop",
		["image"] = "images/dungeongrid/dungeonfloorheart.png",
	},
	
	{
		["name"] = "Stairs Item",
		["image"] = "images/dungeongrid/dungeonstairs.png",
	},
	
	--Level 7
	{
		["name"] = "Heart Floor Drop",
		["image"] = "images/dungeongrid/dungeonfloorheart.png",
	},
	
	{
		["name"] = "Stairs Item",
		["image"] = "images/dungeongrid/dungeonstairs.png",
	},
	
	-- Level 8
	{
		["name"] = "Heart Floor Drop",
		["image"] = "images/dungeongrid/dungeonfloorheart.png",
	},
	
	{
		["name"] = "Stairs Item",
		["image"] = "images/dungeongrid/dungeonstairs.png",
	},
	
	{
		["name"] = "Stairs Item",
		["image"] = "images/dungeongrid/dungeonstairs.png",
	},
	
	-- Level 9
	{
		["name"] = "Stairs Item",
		["image"] = "images/dungeongrid/dungeonstairs.png",
	},
	
	{
		["name"] = "Stairs Item",
		["image"] = "images/dungeongrid/dungeonstairs.png",
	},
	
	-- Overworld
	{
		["name"] = "Coast Item",
		["image"] = "images/dungeongrid/coastitem.png"
	},
	
	{
		["name"] = "Armos Item",
		["image"] = "images/dungeongrid/armos.png"
	},
	
	{
		["name"] = "White Sword Cave",
		["image"] = "images/dungeongrid/whiteswordcave.png"
	}
}

-- Define items to add to the palette by adding the necesarry data here
-- Attributes set are similar to what you'd do when defining items in json, just slightly less verbose
local GridPaletteData = {
	-- Define default square here, this is what any compact map square will default to, or revert to when the applied palette is removed
	[0] = {
		["name"] = "Stairs",
		["code"] = "gridpalettestairs",
		["image"] = "images/dungeongrid/dungeonstairs.png"
	},

	{
		["name"] = "Book",
		["code"] = "gridpalettebook",
		["image"] = "images/dungeongrid/book.png"
	},
	
	{
		["name"] = "Boomerang",
		["code"] = "gridpaletteboomerang",
		["image"] = "images/dungeongrid/boomerang.png"
	},
	
	{
		["name"] = "Bow",
		["code"] = "gridpalettebow",
		["image"] = "images/dungeongrid/bow.png"
	},
	
	{
		["name"] = "Heart Container",
		["code"] = "gridpaletteheartcontainer",
		["image"] = "images/dungeongrid/heartcontainer.png"
	},
	
	{
		["name"] = "Ladder",
		["code"] = "gridpaletteladder",
		["image"] = "images/dungeongrid/ladder.png"
	},
	
	{
		["name"] = "Magic Boomerang",
		["code"] = "gridpalettemagicboomerang",
		["image"] = "images/dungeongrid/magicboomerang.png"
	},
	
	{
		["name"] = "Magic Key",
		["code"] = "gridpalettemagickey",
		["image"] = "images/dungeongrid/magickey.png"
	},
	
	{
		["name"] = "Magic Shield",
		["code"] = "gridpalettemagicshield",
		["image"] = "images/dungeongrid/magicshield.png"
	},
	
	{
		["name"] = "Power Bracelet",
		["code"] = "gridpalettepowerbracelet",
		["image"] = "images/dungeongrid/powerbracelet.png"
	},
	
	{
		["name"] = "Raft",
		["code"] = "gridpaletteraft",
		["image"] = "images/dungeongrid/raft.png"
	},
	
	{
		["name"] = "Recorder",
		["code"] = "gridpaletterecorder",
		["image"] = "images/dungeongrid/recorder.png"
	},
	
	{
		["name"] = "Red Candle",
		["code"] = "gridpaletteredcandle",
		["image"] = "images/dungeongrid/redcandle.png"
	},
	
	{
		["name"] = "Red Ring",
		["code"] = "gridpaletteredring",
		["image"] = "images/dungeongrid/redring.png"
	},
	
	{
		["name"] = "Silver Arrow",
		["code"] = "gridpalettesilverarrow",
		["image"] = "images/dungeongrid/silverarrow.png"
	},
	
	{
		["name"] = "Wand",
		["code"] = "gridpalettewand",
		["image"] = "images/dungeongrid/wand.png"
	},
	
	{
		["name"] = "White Sword",
		["code"] = "gridpalettewhitesword",
		["image"] = "images/dungeongrid/whitesword.png"
	},
	
	{
		["name"] = "Not Available",
		["code"] = "gridpalettenothing",
		["image"] = "images/dungeongrid/nothing.png"
	}
}

local GridStairsImage
local GridFloorImage
local GridCurrentPalette

GridPaletteItem = CustomItem:extend()

-- GridPaletteItems are the mutually exclusive items that you use to control what you're putting on a map square
-- There are no properties used on this one since we do not want this item to change by using undo
-- In addition there is no handling for saving and loading since we want it to return to its default state if a save is loaded

function GridPaletteItem:init(name,code,image,index)
	self:createItem(name)
	self.code = code
	self.Active = false
	self.activeImage = image
	self.index = index
	self.disabledImage = ImageReference:FromImageReference(self.activeImage, "@disabled")
	self.ItemInstance.PotentialIcon = self.activeImage
	
	-- The 0 indexed item is our default state, and also the state our palette should start as
	if index == 0 then
		GridStairsImage = self
		GridCurrentPalette = self
	elseif index == -1 then
		GridFloorImage = self
	end
	
	self:UpdateIcon()
end

function GridPaletteItem:UpdateIcon()
	if self.Active then
		self.ItemInstance.Icon = self.activeImage
	else
		self.ItemInstance.Icon = self.disabledImage
	end
end

function GridPaletteItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function GridPaletteItem:providesCode(code)
    if code == self.code and self.Active then
        return 1
    end
    return 0
end

function GridPaletteItem:onLeftClick()
	-- Technically this works fine without checking if the item isn't active, but this is cleaner
	if not self.Active then
		GridCurrentPalette.Active = false
		GridCurrentPalette:UpdateIcon()
		GridCurrentPalette = self
		self.Active = true
		-- Since we're not using setProperty we also can't use PropertyChanged() and so have to push the icon update here.
		self:UpdateIcon()
	end
end

function GridPaletteItem:onRightClick()
	-- We do need to double check that the user is right-clicking an active palette item before we set the palette to GridStairsImage
	if self.Active then
		GridCurrentPalette = GridStairsImage
		self.Active = false
		-- Since we're not using setProperty we also can't use PropertyChanged() and so have to push the icon update here
		self:UpdateIcon()
	end
end

-- Since we're not interested in saving palette state, we make the save function return nothing instead of the default empty table
function GridPaletteItem:save()
end

for i,data in pairs(GridPaletteData) do
	-- We convert the image paths to references here to make them easier to reference later
	data["image"] = ImageReference:FromPackRelativePath(data["image"])
	local newItem = GridPaletteItem(data["name"], data["code"], data["image"], i)
end

-- DungeonGridItem is the squares that make up the map
-- Properties:
-- active - boolean if item is active or not
-- index - integer storing the index of the current palette, corresponding to its position in GridPaletteData
-- Variables:
-- self.RightClickImage - The image to be set to when the square is right-clicked
-- self.AssignedImage - The image that the square has currently been set to by left-clicking

DungeonGridItem = CustomItem:extend()

-- Codes are incremented through passing the i value of a for loop
-- We don't need any other variables passed on init since the rest is fixed information
function DungeonGridItem:init(name,image,iteration)
	self:createItem(name)
    self.code = "dungeongrid" .. iteration
	self:setProperty("active", false)
	self.iteration = iteration
	self:setProperty("index", GridStairsImage.index)
	self.DefaultImage = image
    -- self.RightClickImage = ImageReference:FromPackRelativePath(OnRightClickGridImage)
    self.AssignedImage = self:getPalette()
    self.ItemInstance.PotentialIcon = self.AssignedImage

    self:updateIcon()
end

function DungeonGridItem:getPalette()
	local index = self:getIndex()
	if index == 0 then
		return self.DefaultImage
	end
	return GridPaletteData[index]["image"]
end

function DungeonGridItem:getActive()
	return self:getProperty("active")
end

function DungeonGridItem:getIndex()
	return self:getProperty("index")
end

function DungeonGridItem:updateIcon()
	if self:getActive() then
		self.ItemInstance.Icon = ImageReference:FromImageReference(self.AssignedImage, OnRightClickGridImage)
	else
		self.ItemInstance.Icon = self.AssignedImage
	end
end

function DungeonGridItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function DungeonGridItem:providesCode(code)
    if code == self.code and self:getActive() then
        return 1
    end
    return 0
end

function DungeonGridItem:onLeftClick()
	-- If the index on our clicked square is the same as the index of our palette, set to the blank index
	if self:getIndex() == GridCurrentPalette.index then
		self:setProperty("index", GridStairsImage.index)
	-- Otherwise, set it to the index of our active palette
	else
		self:setProperty("index", GridCurrentPalette.index)
	end
end

-- Right clicking swaps between the item set as OnRightClickGridImage showing or not
-- Worth mentioning that right-clicking purposefully doesn't delete the underlying item
-- It's friendlier for misclicks that way
function DungeonGridItem:onRightClick()
	if self:getActive() then
		self:setProperty("active", false)
	else
		self:setProperty("active", true)
	end
end

function DungeonGridItem:propertyChanged(key, value)
	-- If the property changed was the index, we need to update AssignedImage used
	if key == "index" then
		self.AssignedImage = self:getPalette()
	end
    self:updateIcon()
end

-- Unlike the GridPaletteItems we do save the properties we've set here, we want them to show up again if someone saves/loads
function DungeonGridItem:save()
    local saveData = {
		["active"] = self:getActive(),
		["index"] = self:getIndex()
	}
    return saveData
end

function DungeonGridItem:load(data)
    if data ~= nil then
        self:setProperty("active", data["active"])
		self:setProperty("index", data["index"])
	end
    return true
end

for i,data in pairs(DungeonGridData) do
	data["image"] = ImageReference:FromPackRelativePath(data["image"])
	local newItem = DungeonGridItem(data["name"],data["image"],i)
end