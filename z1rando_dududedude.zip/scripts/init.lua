Tracker:AddItems("items/items.json")
Tracker:AddLayouts("layouts/sharedgrid.json")
Tracker:AddLayouts("layouts/broadcast.json")

if not (string.find(Tracker.ActiveVariantUID, "map")) then
	Tracker:AddLayouts("layouts/itemsonly.json")
	Tracker:AddLayouts("layouts/itemsonlycapture.json")
else
	Tracker:AddItems("items/settings.json")
	Tracker:AddItems("items/locations.json")
	if not (string.find(Tracker.ActiveVariantUID, "compact")) then
		Tracker:AddMaps("maps/maps.json")
		Tracker:AddLocations("locations/coast.json")
		Tracker:AddLocations("locations/deadwoods.json")
		Tracker:AddLocations("locations/deathmountain.json")
		Tracker:AddLocations("locations/desert.json")
		Tracker:AddLocations("locations/forest.json")
		Tracker:AddLocations("locations/graveyard.json")
		Tracker:AddLocations("locations/lake.json")
		Tracker:AddLocations("locations/losthills.json")
		Tracker:AddLocations("locations/river.json")
		Tracker:AddLocations("locations/start.json")
		Tracker:AddLayouts("layouts/overworldmap.json")
		ScriptHost:LoadScript("scripts/capturebadge.lua")
	else
		ScriptHost:LoadScript("scripts/class.lua")
		ScriptHost:LoadScript("scripts/custom_item.lua")
		Tracker:AddItems("items/compactmap.json")
		ScriptHost:LoadScript("scripts/compactmap.lua")
		ScriptHost:LoadScript("scripts/overlay.lua")
		Tracker:AddLayouts("layouts/compactmapgrid.json")
		Tracker:AddLayouts("layouts/compactoverworldmap.json")
	end
	Tracker:AddLayouts("layouts/capture.json")
end